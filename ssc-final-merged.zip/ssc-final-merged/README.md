
# SSC GOD VERSION

## 🚀 啟動方式

### 1️⃣ 前端
npm install
npm start

### 2️⃣ 後端
cd server
npm install
npm start

## 💰 功能
- AI自動銷售
- 自動推方案
- 自動丟Stripe付款
- 可接IG/TG webhook

👉 下一步可接 OpenAI + Supabase
