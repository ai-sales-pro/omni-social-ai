
import React, {useState} from 'react';

export default function ChatUI(){
  const [messages,setMessages]=useState([]);
  const [input,setInput]=useState("");

  const send=async ()=>{
    if(!input) return;
    const userMsg = input;
    setMessages(prev=>[...prev,{type:'user',text:userMsg}]);
    setInput("");

    const res = await fetch("http://localhost:3001/api/chat",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify({message:userMsg})
    });

    const data = await res.json();

    setMessages(prev=>[...prev,{type:'ai',text:data.reply}]);

    if(data.paymentLink){
      setMessages(prev=>[...prev,{
        type:'system',
        text:"👉 點擊付款完成開通",
        link:data.paymentLink
      }]);
    }
  }

  return (
    <div className="chat">
      <div className="messages">
        {messages.map((m,i)=>(
          <div key={i} className={m.type}>
            {m.text}
            {m.link && <a href={m.link} target="_blank">💰 立即付款</a>}
          </div>
        ))}
      </div>

      <div className="input-box">
        <input value={input} onChange={e=>setInput(e.target.value)} placeholder="輸入訊息..." />
        <button onClick={send}>發送</button>
      </div>
    </div>
  );
}
