
import React from 'react';

export default function GlassCard({children}) {
  return <div className="glass">{children}</div>;
}
