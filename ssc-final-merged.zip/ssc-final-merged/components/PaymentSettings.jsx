import { useState } from "react";

export default function PaymentSettings() {
  const [ownerId, setOwnerId] = useState("");
  const [paymentLink, setPaymentLink] = useState("");
  const [status, setStatus] = useState("");

  const API_URL = "https://ai-sales-system-6iu2.onrender.com";

  const saveLink = async () => {
    try {
      const res = await fetch(`${API_URL}/api/payment-link`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ownerId,
          paymentLink
        })
      });

      const data = await res.json();

      if (data.ok) {
        setStatus("✅ 已儲存成功");
      } else {
        setStatus("❌ 儲存失敗");
      }
    } catch (err) {
      setStatus("❌ 發生錯誤");
    }
  };

  const loadLink = async () => {
    try {
      const res = await fetch(`${API_URL}/api/payment-link/${ownerId}`);
      const data = await res.json();

      if (data.paymentLink) {
        setPaymentLink(data.paymentLink);
        setStatus("✅ 已載入");
      } else {
        setStatus("⚠️ 尚未設定");
      }
    } catch (err) {
      setStatus("❌ 讀取失敗");
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>💰 付款連結設定</h2>

      <input
        style={styles.input}
        placeholder="輸入你的 ownerId（例：boss_001）"
        value={ownerId}
        onChange={(e) => setOwnerId(e.target.value)}
      />

      <input
        style={styles.input}
        placeholder="貼上你的付款連結（Stripe / PayPal / Line Pay）"
        value={paymentLink}
        onChange={(e) => setPaymentLink(e.target.value)}
      />

      <div style={styles.buttons}>
        <button style={styles.btn} onClick={saveLink}>
          💾 儲存
        </button>

        <button style={styles.btn} onClick={loadLink}>
          📥 載入
        </button>
      </div>

      <p style={styles.status}>{status}</p>
    </div>
  );
}

const styles = {
  container: {
    maxWidth: 400,
    margin: "100px auto",
    padding: 20,
    borderRadius: 12,
    background: "#1e1e2f",
    color: "#fff",
    textAlign: "center"
  },
  title: {
    marginBottom: 20
  },
  input: {
    width: "100%",
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
    border: "none"
  },
  buttons: {
    display: "flex",
    gap: 10
  },
  btn: {
    flex: 1,
    padding: 10,
    borderRadius: 8,
    border: "none",
    background: "#6c5ce7",
    color: "#fff",
    cursor: "pointer"
  },
  status: {
    marginTop: 10
  }
};
