import React from "react";

export default function Sidebar({ page, setPage }) {
  const items = [
    { label: "Dashboard", icon: "◈" },
    { label: "Inbox", icon: "✉" },
    { label: "Leads", icon: "◎" },
    { label: "Payments", icon: "$" },
    { label: "Customers", icon: "◉" },
    { label: "Channels", icon: "🔗" },
    { label: "AI Settings", icon: "✦" },
    { label: "Bank", icon: "▣" },
    { label: "Analytics", icon: "△" },
    { label: "Admin", icon: "◆" }
  ];

  return (
    <div style={styles.sidebar}>
      <div style={styles.logoWrap}>
        <div style={styles.logoIcon} />
        <div>
          <div style={styles.logoText}>AI Sales OS</div>
          <div style={styles.logoSub}>Auto Closing System</div>
        </div>
      </div>

      <div style={{ flex: 1 }}>
        {items.map((item) => {
          const active = page === item.label;

          return (
            <div
              key={item.label}
              onClick={() => setPage(item.label)}
              style={{
                ...styles.menu,
                ...(active ? styles.activeMenu : {})
              }}
              onMouseEnter={(e) => {
                if (!active) {
                  Object.assign(e.currentTarget.style, styles.hoverMenu);
                }
              }}
              onMouseLeave={(e) => {
                if (!active) {
                  Object.assign(e.currentTarget.style, styles.menu);
                }
              }}
            >
              <span
                style={{
                  ...styles.icon,
                  ...(active ? styles.activeIcon : {})
                }}
              >
                {item.icon}
              </span>

              <span style={styles.label}>{item.label}</span>

              {item.label === "Channels" && !active && (
                <span style={styles.badge}>NEW</span>
              )}

              {active && <div style={styles.activeBar} />}
            </div>
          );
        })}
      </div>

      <div style={styles.statusCard}>
        <div style={styles.statusDot} />
        <div>
          <div style={styles.statusTitle}>系統運行中</div>
          <div style={styles.statusSub}>全自動成交模式</div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  sidebar: {
    position: "fixed",
    left: 0,
    top: 0,
    width: 260,
    height: "100vh",
    padding: "26px 18px",
    display: "flex",
    flexDirection: "column",
    zIndex: 10,
    background: "rgba(10,6,25,0.78)",
    backdropFilter: "blur(20px)",
    WebkitBackdropFilter: "blur(20px)",
    borderRight: "1px solid rgba(255,255,255,0.08)",
    boxShadow: "0 0 80px rgba(140,90,255,0.18)"
  },

  logoWrap: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    marginBottom: 34
  },

  logoIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    background: "linear-gradient(135deg,#9d5cff,#5f7cff)",
    boxShadow:
      "0 0 20px rgba(140,90,255,0.8), inset 0 0 10px rgba(255,255,255,0.3)"
  },

  logoText: {
    fontSize: 18,
    fontWeight: 800,
    color: "#fff",
    letterSpacing: "1px"
  },

  logoSub: {
    fontSize: 11,
    opacity: 0.6,
    color: "#fff"
  },

  menu: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "14px 16px",
    marginBottom: 12,
    borderRadius: 14,
    cursor: "pointer",
    transition: "all 0.25s ease",
    color: "rgba(255,255,255,0.82)",
    background: "rgba(255,255,255,0.03)",
    border: "1px solid rgba(255,255,255,0.06)",
    position: "relative"
  },

  hoverMenu: {
    background: "rgba(255,255,255,0.09)",
    border: "1px solid rgba(255,255,255,0.14)",
    transform: "translateX(6px)"
  },

  activeMenu: {
    color: "#fff",
    fontWeight: 700,
    background:
      "linear-gradient(135deg, rgba(140,90,255,0.35), rgba(0,200,255,0.18))",
    border: "1px solid rgba(180,140,255,0.45)",
    boxShadow:
      "0 0 30px rgba(132,94,255,0.35), inset 0 0 12px rgba(255,255,255,0.06)"
  },

  icon: {
    width: 24,
    textAlign: "center",
    fontSize: 15,
    opacity: 0.9
  },

  activeIcon: {
    textShadow: "0 0 16px rgba(160,120,255,0.9)"
  },

  label: {
    fontSize: 15
  },

  badge: {
    marginLeft: "auto",
    fontSize: 10,
    padding: "2px 6px",
    borderRadius: 6,
    background: "linear-gradient(135deg,#ff4d6d,#ff8fa3)",
    color: "#fff",
    fontWeight: 700,
    boxShadow: "0 0 10px rgba(255,100,150,0.6)"
  },

  activeBar: {
    position: "absolute",
    right: 10,
    width: 6,
    height: 26,
    borderRadius: 6,
    background: "linear-gradient(#a78bfa,#7c3aed)",
    boxShadow: "0 0 14px rgba(167,139,250,0.9)"
  },

  statusCard: {
    marginTop: "auto",
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: 14,
    borderRadius: 14,
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)"
  },

  statusDot: {
    width: 10,
    height: 10,
    borderRadius: "50%",
    background: "#67f0b4",
    boxShadow: "0 0 12px #67f0b4"
  },

  statusTitle: {
    fontSize: 12,
    color: "#67f0b4",
    fontWeight: 600
  },

  statusSub: {
    fontSize: 11,
    opacity: 0.6,
    color: "#fff"
  }
};

export default Sidebar;