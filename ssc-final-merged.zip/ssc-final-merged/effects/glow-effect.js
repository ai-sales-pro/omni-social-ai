let cleanupGlowEffect = null;

export function initGlowEffect() {
  const glow = document.getElementById("mouse-glow");
  if (!glow) return () => {};

  let currentX = window.innerWidth / 2;
  let currentY = window.innerHeight / 2;
  let targetX = currentX;
  let targetY = currentY;

  let rafId = null;
  let running = true;

  const updateTarget = (e) => {
    targetX = e.clientX;
    targetY = e.clientY;
  };

  const animate = () => {
    if (!running) return;

    // 🔥 平滑程度（數字越小越慢）
    const ease = 0.08;

    currentX += (targetX - currentX) * ease;
    currentY += (targetY - currentY) * ease;

    glow.style.transform = `translate3d(${currentX}px, ${currentY}px, 0) translate(-50%, -50%)`;

    rafId = requestAnimationFrame(animate);
  };

  document.addEventListener("mousemove", updateTarget, { passive: true });

  rafId = requestAnimationFrame(animate);

  const destroy = () => {
    running = false;

    document.removeEventListener("mousemove", updateTarget);

    if (rafId) cancelAnimationFrame(rafId);
  };

  cleanupGlowEffect = destroy;
  return destroy;
}

export function destroyGlowEffect() {
  if (cleanupGlowEffect) {
    cleanupGlowEffect();
    cleanupGlowEffect = null;
  }
}