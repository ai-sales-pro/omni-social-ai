import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// 先關掉舊風格，避免跟 pro.css 打架
// import './styles/glass.css';
// import './styles/neon.css';

import './styles/animation.css';
import './styles/pro.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);