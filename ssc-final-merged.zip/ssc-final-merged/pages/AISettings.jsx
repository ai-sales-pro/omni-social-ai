import React, { useEffect, useMemo, useState } from "react";

function getOwnerId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("ownerId") || "";
}

const INDUSTRY_OPTIONS = [
  { value: "fortune", label: "命理 / 感情 / 能量" },
  { value: "beauty", label: "美業 / 醫美" },
  { value: "real_estate", label: "房仲 / 地產" },
  { value: "ecommerce", label: "電商 / 商品銷售" },
  { value: "education", label: "教育 / 課程 / 顧問" },
  { value: "fitness", label: "健身 / 教練" },
  { value: "consulting", label: "商務顧問 / 高價服務" },
  { value: "general", label: "一般服務業" }
];

const LANGUAGE_OPTIONS = [
  { value: "zh-TW", label: "繁體中文" },
  { value: "zh-CN", label: "简体中文" },
  { value: "en", label: "English" },
  { value: "th", label: "ไทย" },
  { value: "ja", label: "日本語" },
  { value: "ko", label: "한국어" }
];

const TONE_OPTIONS = [
  { value: "soft", label: "柔和陪伴" },
  { value: "closing", label: "成交推進" },
  { value: "premium", label: "高端品牌感" }
];

export default function AISettings() {
  const ownerId = getOwnerId();

  const [autoReply, setAutoReply] = useState(true);
  const [autoPaymentPush, setAutoPaymentPush] = useState(true);
  const [customerAnalysis, setCustomerAnalysis] = useState(true);
  const [followUpMode, setFollowUpMode] = useState("standard");
  const [defaultPlan, setDefaultPlan] = useState("pro");
  const [toneStyle, setToneStyle] = useState("closing");

  const [industry, setIndustry] = useState("fortune");
  const [primaryLanguage, setPrimaryLanguage] = useState("zh-TW");
  const [businessName, setBusinessName] = useState("");
  const [productName, setProductName] = useState("");
  const [productPrice, setProductPrice] = useState("");
  const [paymentLink, setPaymentLink] = useState("");
  const [brandStyle, setBrandStyle] = useState("");
  const [customPrompt, setCustomPrompt] = useState("");

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function loadSettings() {
      if (!ownerId) {
        setLoading(false);
        return;
      }

      try {
        const [aiRes, paymentRes] = await Promise.all([
          fetch(`/api/ai-settings/${ownerId}`),
          fetch(`/api/payment-link/${ownerId}`)
        ]);

        const aiData = await aiRes.json();
        const paymentData = await paymentRes.json();

        if (aiData.ok && aiData.settings) {
          const s = aiData.settings;

          setAutoReply(s.auto_reply ?? s.autoMode ?? true);
          setAutoPaymentPush(s.auto_payment_push ?? true);
          setCustomerAnalysis(s.customer_analysis ?? true);
          setFollowUpMode(s.follow_up_mode || "standard");
          setDefaultPlan(s.default_plan || "pro");
          setToneStyle(s.tone_style || "closing");

          setIndustry(s.industry || "fortune");
          setPrimaryLanguage(s.primary_language || "zh-TW");
          setBusinessName(s.business_name || "");
          setProductName(s.product_name || "");
          setProductPrice(
            s.product_price !== undefined && s.product_price !== null
              ? String(s.product_price)
              : ""
          );
          setBrandStyle(s.brand_style || "");
          setCustomPrompt(s.custom_prompt || "");
        }

        if (paymentData.ok) {
          setPaymentLink(paymentData.paymentLink || "");
        }
      } catch (err) {
        console.error("load ai settings error:", err);
        setMessage("讀取設定失敗");
      } finally {
        setLoading(false);
      }
    }

    loadSettings();
  }, [ownerId]);

  async function saveSettings() {
    if (!ownerId) {
      setMessage("缺少 ownerId");
      return;
    }

    setSaving(true);
    setMessage("");

    try {
      const [aiRes, paymentRes] = await Promise.all([
        fetch("/api/ai-settings", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            ownerId,
            autoReply,
            autoPaymentPush,
            customerAnalysis,
            followUpMode,
            defaultPlan,
            toneStyle,

            industry,
            primaryLanguage,
            businessName,
            productName,
            productPrice: productPrice ? Number(productPrice) : 0,
            brandStyle,
            customPrompt,

            autoMode: autoReply
          })
        }),
        fetch("/api/payment-link", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            ownerId,
            paymentLink
          })
        })
      ]);

      const aiData = await aiRes.json();
      const paymentData = await paymentRes.json();

      if (aiData.ok && paymentData.ok) {
        setMessage("AI 設定已儲存");
      } else {
        setMessage(aiData.message || paymentData.message || "儲存失敗");
      }
    } catch (err) {
      console.error("save ai settings error:", err);
      setMessage("儲存失敗");
    } finally {
      setSaving(false);
    }
  }

  const aiSummary = useMemo(() => {
    const industryLabel =
      INDUSTRY_OPTIONS.find((i) => i.value === industry)?.label || industry;
    const languageLabel =
      LANGUAGE_OPTIONS.find((i) => i.value === primaryLanguage)?.label ||
      primaryLanguage;
    const toneLabel =
      TONE_OPTIONS.find((i) => i.value === toneStyle)?.label || toneStyle;

    return {
      industryLabel,
      languageLabel,
      toneLabel
    };
  }, [industry, primaryLanguage, toneStyle]);

  return (
    <div>
      <div style={styles.heroCard}>
        <div style={styles.heroGlow} />
        <div style={styles.heroTopRow}>
          <div>
            <h1 className="page-title" style={styles.pageTitle}>
              AI Settings
            </h1>
            <p className="page-subtitle" style={styles.pageSubtitle}>
              {ownerId ? `目前帳號：${ownerId}` : "請帶入 ownerId"}
            </p>
          </div>

          <div style={styles.heroBadge}>AI SALES BRAIN</div>
        </div>

        <p style={styles.heroDesc}>
          這裡是整個 AI 自動成交系統的大腦。你可以設定行業、商品、語言、話術風格、
          付款方式與自動化程度，讓 AI 依照你的商業模式自動成交。
        </p>

        <div style={styles.actionRow}>
          <button
            className="btn-pro"
            onClick={saveSettings}
            disabled={saving}
            style={styles.primaryBtn}
          >
            {saving ? "儲存中..." : "💾 儲存設定"}
          </button>

          <button
            className="btn-pro"
            onClick={() => window.location.reload()}
            style={styles.secondaryBtn}
          >
            🔄 重新整理
          </button>
        </div>
      </div>

      {message && (
        <div
          className="glass-card glow-border"
          style={{
            ...styles.noticeCard,
            ...(message.includes("失敗") ? styles.noticeError : styles.noticeOk)
          }}
        >
          {message}
        </div>
      )}

      <div style={styles.grid}>
        <div className="glass-card glow-border" style={styles.card}>
          <h3 style={styles.cardTitle}>AI 核心功能</h3>

          <ToggleRow
            label="AI 自動回覆"
            value={autoReply}
            onClick={() => setAutoReply(!autoReply)}
          />

          <ToggleRow
            label="自動推付款連結"
            value={autoPaymentPush}
            onClick={() => setAutoPaymentPush(!autoPaymentPush)}
          />

          <ToggleRow
            label="客戶分析"
            value={customerAnalysis}
            onClick={() => setCustomerAnalysis(!customerAnalysis)}
          />
        </div>

        <div className="glass-card glow-border" style={styles.card}>
          <h3 style={styles.cardTitle}>追單模式</h3>

          <select
            value={followUpMode}
            onChange={(e) => setFollowUpMode(e.target.value)}
            style={styles.select}
          >
            <option value="gentle">溫和</option>
            <option value="standard">標準</option>
            <option value="strong">強力</option>
          </select>

          <p style={styles.desc}>
            {followUpMode === "gentle" && "偏柔和提醒，適合低壓客戶"}
            {followUpMode === "standard" && "一般成交模式，最平衡"}
            {followUpMode === "strong" && "高推進模式，適合高意圖客戶"}
          </p>
        </div>

        <div className="glass-card glow-border" style={styles.card}>
          <h3 style={styles.cardTitle}>預設付款方案</h3>

          <select
            value={defaultPlan}
            onChange={(e) => setDefaultPlan(e.target.value)}
            style={styles.select}
          >
            <option value="starter">Starter</option>
            <option value="pro">Pro</option>
            <option value="elite">Elite</option>
          </select>

          <p style={styles.desc}>
            目前預設方案：<strong>{defaultPlan.toUpperCase()}</strong>
          </p>
        </div>

        <div className="glass-card glow-border" style={styles.card}>
          <h3 style={styles.cardTitle}>AI 話術風格</h3>

          <select
            value={toneStyle}
            onChange={(e) => setToneStyle(e.target.value)}
            style={styles.select}
          >
            {TONE_OPTIONS.map((item) => (
              <option key={item.value} value={item.value}>
                {item.label}
              </option>
            ))}
          </select>

          <p style={styles.desc}>
            {toneStyle === "soft" && "偏安撫、陪伴、建立信任"}
            {toneStyle === "closing" && "偏成交推進、引導下單"}
            {toneStyle === "premium" && "偏高級感、高價值客戶話術"}
          </p>
        </div>
      </div>

      <div style={styles.gridWide}>
        <div className="glass-card glow-border" style={styles.card}>
          <h3 style={styles.cardTitle}>行業 / 語言 / 品牌</h3>

          <Field label="行業">
            <select
              value={industry}
              onChange={(e) => setIndustry(e.target.value)}
              style={styles.select}
            >
              {INDUSTRY_OPTIONS.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </Field>

          <Field label="主要語言">
            <select
              value={primaryLanguage}
              onChange={(e) => setPrimaryLanguage(e.target.value)}
              style={styles.select}
            >
              {LANGUAGE_OPTIONS.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>
          </Field>

          <Field label="品牌名稱">
            <input
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              placeholder="例如：AI Sales OS / 泰靈金願 / Your Brand"
              style={styles.input}
            />
          </Field>

          <Field label="品牌風格">
            <textarea
              value={brandStyle}
              onChange={(e) => setBrandStyle(e.target.value)}
              placeholder="例如：專業、高級、值得信任、先共感再成交"
              style={styles.textareaSmall}
            />
          </Field>
        </div>

        <div className="glass-card glow-border" style={styles.card}>
          <h3 style={styles.cardTitle}>商品 / 收款設定</h3>

          <Field label="商品名稱">
            <input
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              placeholder="例如：感情挽回完整方案 / 高級顧問服務 / 美業療程"
              style={styles.input}
            />
          </Field>

          <Field label="商品價格（USD）">
            <input
              value={productPrice}
              onChange={(e) => setProductPrice(e.target.value)}
              placeholder="例如：3000"
              style={styles.input}
              inputMode="decimal"
            />
          </Field>

          <Field label="付款連結">
            <input
              value={paymentLink}
              onChange={(e) => setPaymentLink(e.target.value)}
              placeholder="貼上 Stripe / Payment Link"
              style={styles.input}
            />
          </Field>

          <div style={styles.tipBox}>
            <div style={styles.tipTitle}>高價成交建議</div>
            <div style={styles.tipText}>
              AI 不會一開始就直接報價，而是先分析需求、建立信任，再引導成交。
              當客人進入高意圖狀態，才推付款連結。
            </div>
          </div>
        </div>
      </div>

      <div className="glass-card glow-border" style={styles.card}>
        <h3 style={styles.cardTitle}>AI 高階指令（神級控制）</h3>

        <textarea
          value={customPrompt}
          onChange={(e) => setCustomPrompt(e.target.value)}
          placeholder="例如：先安撫，再分析，再引導成交。不要太硬。遇到高意圖客戶要更積極收單。遇到英文客戶請用自然英文回覆。"
          style={styles.textareaLarge}
        />

        <p style={styles.desc}>
          這裡可以補充你想讓 AI 遵守的特殊規則。這一欄會直接影響成交風格，是整個系統最強的控制區。
        </p>
      </div>

      <div className="glass-card glow-border" style={{ ...styles.card, padding: 22 }}>
        <h3 style={{ ...styles.cardTitle, marginBottom: 16 }}>目前 AI 狀態總覽</h3>

        <table className="panel-table">
          <thead>
            <tr>
              <th>項目</th>
              <th>狀態</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>AI 自動回覆</td>
              <td>{loading ? "讀取中..." : autoReply ? "啟用中" : "已關閉"}</td>
            </tr>
            <tr>
              <td>自動推付款連結</td>
              <td>{loading ? "讀取中..." : autoPaymentPush ? "啟用中" : "已關閉"}</td>
            </tr>
            <tr>
              <td>客戶分析</td>
              <td>{loading ? "讀取中..." : customerAnalysis ? "啟用中" : "已關閉"}</td>
            </tr>
            <tr>
              <td>追單模式</td>
              <td>{loading ? "讀取中..." : followUpMode}</td>
            </tr>
            <tr>
              <td>預設方案</td>
              <td>{loading ? "讀取中..." : defaultPlan}</td>
            </tr>
            <tr>
              <td>話術風格</td>
              <td>{loading ? "讀取中..." : aiSummary.toneLabel}</td>
            </tr>
            <tr>
              <td>行業</td>
              <td>{loading ? "讀取中..." : aiSummary.industryLabel}</td>
            </tr>
            <tr>
              <td>主要語言</td>
              <td>{loading ? "讀取中..." : aiSummary.languageLabel}</td>
            </tr>
            <tr>
              <td>商品名稱</td>
              <td>{loading ? "讀取中..." : productName || "-"}</td>
            </tr>
            <tr>
              <td>商品價格</td>
              <td>{loading ? "讀取中..." : productPrice ? `$${productPrice}` : "-"}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={styles.fieldLabel}>{label}</div>
      {children}
    </div>
  );
}

function ToggleRow({ label, value, onClick }) {
  return (
    <div style={styles.row}>
      <span>{label}</span>
      <button
        className="btn-pro"
        onClick={onClick}
        style={value ? styles.toggleOn : styles.toggleOff}
      >
        {value ? "開啟中" : "已關閉"}
      </button>
    </div>
  );
}

const styles = {
  heroCard: {
    position: "relative",
    overflow: "hidden",
    borderRadius: 24,
    padding: 24,
    marginBottom: 22,
    background:
      "linear-gradient(135deg, rgba(44,24,84,0.62), rgba(18,12,38,0.88))",
    border: "1px solid rgba(255,255,255,0.08)",
    boxShadow:
      "0 18px 60px rgba(0,0,0,0.24), 0 0 36px rgba(140,90,255,0.10)"
  },
  heroGlow: {
    position: "absolute",
    top: -80,
    right: -60,
    width: 260,
    height: 260,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(140,90,255,0.22), transparent 70%)",
    filter: "blur(10px)",
    pointerEvents: "none"
  },
  heroTopRow: {
    display: "flex",
    justifyContent: "space-between",
    gap: 18,
    alignItems: "flex-start",
    flexWrap: "wrap"
  },
  pageTitle: {
    marginTop: 0,
    marginBottom: 6
  },
  pageSubtitle: {
    margin: 0
  },
  heroBadge: {
    padding: "8px 12px",
    borderRadius: 999,
    fontSize: 12,
    letterSpacing: "0.08em",
    color: "#F3EBFF",
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.10)",
    boxShadow: "0 0 20px rgba(140,90,255,0.14)"
  },
  heroDesc: {
    marginTop: 14,
    marginBottom: 18,
    maxWidth: 880,
    lineHeight: 1.8,
    color: "rgba(235,225,255,0.78)"
  },
  actionRow: {
    display: "flex",
    gap: 12,
    flexWrap: "wrap"
  },
  primaryBtn: {
    minWidth: 170
  },
  secondaryBtn: {
    minWidth: 150,
    opacity: 0.95
  },
  noticeCard: {
    padding: 14,
    marginBottom: 20,
    color: "#EDE4FF"
  },
  noticeOk: {
    background: "rgba(124,255,191,0.08)"
  },
  noticeError: {
    background: "rgba(255,120,140,0.08)"
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
    gap: 20,
    marginBottom: 24
  },
  gridWide: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
    gap: 20,
    marginBottom: 24
  },
  card: {
    padding: 20
  },
  cardTitle: {
    marginTop: 0,
    marginBottom: 16
  },
  row: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 16,
    marginBottom: 14
  },
  toggleOn: {
    minWidth: 110,
    boxShadow: "0 0 22px rgba(124,255,191,0.14)"
  },
  toggleOff: {
    minWidth: 110,
    opacity: 0.75
  },
  fieldLabel: {
    marginBottom: 8,
    fontSize: 14,
    color: "rgba(235,225,255,0.84)"
  },
  input: {
    width: "100%",
    padding: 12,
    borderRadius: 12,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "white",
    outline: "none",
    boxSizing: "border-box"
  },
  select: {
    width: "100%",
    padding: 12,
    borderRadius: 12,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "white",
    outline: "none",
    boxSizing: "border-box"
  },
  textareaSmall: {
    width: "100%",
    minHeight: 92,
    padding: 12,
    borderRadius: 12,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "white",
    outline: "none",
    boxSizing: "border-box",
    resize: "vertical"
  },
  textareaLarge: {
    width: "100%",
    minHeight: 140,
    padding: 14,
    borderRadius: 14,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "white",
    outline: "none",
    boxSizing: "border-box",
    resize: "vertical",
    marginBottom: 12
  },
  desc: {
    marginTop: 12,
    color: "rgba(235,225,255,0.72)",
    lineHeight: 1.8,
    fontSize: 14
  },
  tipBox: {
    marginTop: 16,
    padding: 14,
    borderRadius: 14,
    background: "rgba(140,90,255,0.08)",
    border: "1px solid rgba(140,90,255,0.14)"
  },
  tipTitle: {
    fontSize: 13,
    fontWeight: 700,
    marginBottom: 6,
    color: "#EDE4FF"
  },
  tipText: {
    color: "rgba(235,225,255,0.72)",
    fontSize: 14,
    lineHeight: 1.75
  }
};