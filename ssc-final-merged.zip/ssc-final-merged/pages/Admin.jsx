import React, { useEffect, useMemo, useState } from "react";

export default function Admin() {
  const [owners, setOwners] = useState([]);
  const [loading, setLoading] = useState(true);
  const [keyword, setKeyword] = useState("");
  const [selectedOwner, setSelectedOwner] = useState(null);

  const [ownerCustomers, setOwnerCustomers] = useState([]);
  const [ownerOrders, setOwnerOrders] = useState([]);
  const [detailTab, setDetailTab] = useState("summary");
  const [detailLoading, setDetailLoading] = useState(false);

  const [adminMsg, setAdminMsg] = useState("");
  const [selectedChatId, setSelectedChatId] = useState("");
  const [aiEnabled, setAiEnabled] = useState(true);

  useEffect(() => {
    async function loadAdminData() {
      try {
        const res = await fetch("/api/admin/owners");
        const data = await res.json();

        if (data.ok) {
          setOwners(data.owners || []);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    loadAdminData();
  }, []);

  useEffect(() => {
    async function loadOwnerDetail() {
      if (!selectedOwner?.owner_id) return;

      setDetailLoading(true);

      try {
        const [customersRes, ordersRes, aiRes] = await Promise.all([
          fetch(`/api/customers/${selectedOwner.owner_id}`),
          fetch(`/api/orders/${selectedOwner.owner_id}`),
          fetch(`/api/ai-settings/${selectedOwner.owner_id}`)
        ]);

        const customersData = await customersRes.json();
        const ordersData = await ordersRes.json();
        const aiData = await aiRes.json();

        setOwnerCustomers(customersData.customers || []);
        setOwnerOrders(ordersData.orders || []);

        if (
          aiData?.settings?.autoMode === false ||
          aiData?.settings?.auto_mode === false ||
          aiData?.settings?.auto_reply === false
        ) {
          setAiEnabled(false);
        } else {
          setAiEnabled(true);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setDetailLoading(false);
      }
    }

    loadOwnerDetail();
  }, [selectedOwner]);

  const filteredOwners = useMemo(() => {
    const q = keyword.toLowerCase();
    return owners.filter((o) =>
      JSON.stringify(o).toLowerCase().includes(q)
    );
  }, [owners, keyword]);

  const totalRevenue = useMemo(() => {
    return ownerOrders.reduce((sum, order) => {
      return sum + Number(order.amount || 0);
    }, 0);
  }, [ownerOrders]);

  const paidCount = useMemo(() => {
    return ownerOrders.filter((order) => order.status === "paid").length;
  }, [ownerOrders]);

  const conversionRate = useMemo(() => {
    if (!owners.length) return 0;
    return Math.round((paidCount / owners.length) * 100);
  }, [owners.length, paidCount]);

  function openOwner(owner) {
    setSelectedOwner(owner);
    setDetailTab("summary");
  }

  function closeOwner() {
    setSelectedOwner(null);
  }

  function openOwnerDashboard(ownerId) {
    window.open(`/dashboard?ownerId=${ownerId}`, "_blank");
  }

  return (
    <div>
      <h1 className="page-title">Admin Only</h1>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 20,
          marginBottom: 30
        }}
      >
        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <h3>💰 總收入</h3>
          <h2>${totalRevenue}</h2>
        </div>

        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <h3>👤 訂閱人數</h3>
          <h2>{owners.length}</h2>
        </div>

        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <h3>🔥 成交數</h3>
          <h2>{paidCount}</h2>
        </div>

        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <h3>📊 轉換率</h3>
          <h2>{conversionRate}%</h2>
        </div>
      </div>

      <input
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
        placeholder="搜尋 ownerId / email"
        className="input-pro"
      />

      <div className="glass-card glow-border">
        <table className="panel-table">
          <tbody>
            {filteredOwners.map((o) => (
              <tr key={o.owner_id}>
                <td>{o.owner_id}</td>
                <td>{o.email}</td>
                <td>
                  <button className="btn-pro" onClick={() => openOwner(o)}>
                    查看
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedOwner && (
        <div
          className="overlay-fade-in"
          style={styles.overlay}
          onClick={closeOwner}
        >
          <div
            className="glass-card glow-border modal-slide-up"
            style={styles.modal}
            onClick={(e) => e.stopPropagation()}
          >
            <h2>老闆：{selectedOwner.owner_id}</h2>

            <div style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap" }}>
              <button className="btn-pro" onClick={() => setDetailTab("summary")}>
                總覽
              </button>
              <button className="btn-pro" onClick={() => setDetailTab("customers")}>
                客戶
              </button>
              <button className="btn-pro" onClick={() => setDetailTab("orders")}>
                訂單
              </button>
              <button className="btn-pro" onClick={() => setDetailTab("ai")}>
                AI 控制
              </button>
              <button className="btn-pro" onClick={() => setDetailTab("ops")}>
                營運操作
              </button>
            </div>

            {detailTab === "summary" && (
              <div className="glass-card" style={{ padding: 16 }}>
                <p>Email: {selectedOwner.email}</p>
                <p>訂單數：{selectedOwner.orders_count || 0}</p>
                <p>客戶數：{selectedOwner.customers_count || 0}</p>
                <p>總營收：${selectedOwner.total_revenue || 0}</p>
                <p>本月營收：${selectedOwner.monthly_revenue || 0}</p>
                <p>方案：{selectedOwner.subscription_plan || selectedOwner.user_plan || "未設定"}</p>
              </div>
            )}

            {detailTab === "customers" && (
              <div className="glass-card" style={{ padding: 16 }}>
                {detailLoading ? (
                  <p>讀取中...</p>
                ) : ownerCustomers.length === 0 ? (
                  <p>尚無客戶資料</p>
                ) : (
                  ownerCustomers.map((c) => (
                    <div key={c.chat_id} style={styles.rowItem}>
                      <span>{c.chat_id}</span>
                      <button
                        className="btn-pro"
                        onClick={() => setSelectedChatId(c.chat_id)}
                      >
                        選擇
                      </button>
                    </div>
                  ))
                )}
              </div>
            )}

            {detailTab === "orders" && (
              <div className="glass-card" style={{ padding: 16 }}>
                {detailLoading ? (
                  <p>讀取中...</p>
                ) : ownerOrders.length === 0 ? (
                  <p>尚無訂單資料</p>
                ) : (
                  ownerOrders.map((o) => (
                    <div key={o.id} style={styles.rowItem}>
                      <span>${o.amount}</span>
                      <span>{o.status}</span>
                    </div>
                  ))
                )}
              </div>
            )}

            {detailTab === "ai" && (
              <div className="glass-card glow-border" style={{ padding: 20 }}>
                <h3>AI 控制</h3>

                <button
                  className="btn-pro"
                  style={{
                    background: aiEnabled ? "#00ffcc33" : "#ffffff10",
                    marginRight: 10
                  }}
                  onClick={async () => {
                    await fetch("/api/admin/toggle-ai", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        ownerId: selectedOwner.owner_id,
                        enabled: true
                      })
                    });
                    setAiEnabled(true);
                    alert("🔥 AI成交模式已開啟");
                  }}
                >
                  🔥 開啟自動成交
                </button>

                <button
                  className="btn-pro"
                  onClick={async () => {
                    await fetch("/api/admin/toggle-ai", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        ownerId: selectedOwner.owner_id,
                        enabled: false
                      })
                    });
                    setAiEnabled(false);
                    alert("⛔ AI已關閉");
                  }}
                >
                  關閉AI
                </button>
              </div>
            )}

            {detailTab === "ops" && (
              <div className="glass-card glow-border" style={{ padding: 20 }}>
                <h3>營運控制</h3>

                <input
                  placeholder="chatId"
                  value={selectedChatId}
                  onChange={(e) => setSelectedChatId(e.target.value)}
                  className="input-pro"
                />

                <input
                  placeholder="輸入訊息"
                  value={adminMsg}
                  onChange={(e) => setAdminMsg(e.target.value)}
                  className="input-pro"
                />

                <button
                  className="btn-pro"
                  onClick={async () => {
                    await fetch("/api/admin/send-message", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        chatId: selectedChatId,
                        text: adminMsg
                      })
                    });
                    alert("已發送");
                  }}
                >
                  發送訊息
                </button>

                <button
                  className="btn-pro"
                  onClick={async () => {
                    await fetch("/api/admin/push-payment", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        ownerId: selectedOwner.owner_id,
                        chatId: selectedChatId
                      })
                    });
                    alert("已推付款");
                  }}
                  style={{ marginLeft: 10 }}
                >
                  🔥 推付款
                </button>

                <button
                  className="btn-pro"
                  onClick={async () => {
                    await fetch("/api/mark-paid", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        chatId: selectedChatId
                      })
                    });
                    alert("已標記付款");
                  }}
                  style={{ marginLeft: 10 }}
                >
                  標記付款
                </button>
              </div>
            )}

            <button
              className="btn-pro"
              onClick={() => openOwnerDashboard(selectedOwner.owner_id)}
            >
              Dashboard
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  overlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(8,5,18,0.7)",
    backdropFilter: "blur(10px)",
    zIndex: 60
  },
  modal: {
    padding: 24,
    borderRadius: 24,
    maxWidth: 1000,
    margin: "40px auto"
  },
  rowItem: {
    display: "flex",
    justifyContent: "space-between",
    padding: "10px 0",
    borderBottom: "1px solid rgba(255,255,255,0.1)"
  }
};