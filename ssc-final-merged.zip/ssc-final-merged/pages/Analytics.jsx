import React, { useEffect, useState } from "react";

function getOwnerId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("ownerId") || "";
}

export default function Analytics() {
  const ownerId = getOwnerId();

  const [revenue, setRevenue] = useState({ total: 0, monthly: 0 });
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      if (!ownerId) {
        setLoading(false);
        return;
      }

      try {
        const [revenueRes, ordersRes, customersRes] = await Promise.all([
          fetch(`/api/revenue/${ownerId}`),
          fetch(`/api/orders/${ownerId}`),
          fetch(`/api/customers/${ownerId}`)
        ]);

        const revenueData = await revenueRes.json();
        const ordersData = await ordersRes.json();
        const customersData = await customersRes.json();

        if (revenueData.ok) {
          setRevenue({
            total: revenueData.total || 0,
            monthly: revenueData.monthly || 0
          });
        }

        if (ordersData.ok) setOrders(ordersData.orders || []);
        if (customersData.ok) setCustomers(customersData.customers || []);
      } catch (err) {
        console.error("analytics error:", err);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [ownerId]);

  const paidOrders = orders.filter((o) => o.status === "paid");

  const avgOrderValue =
    paidOrders.length > 0
      ? Math.round(
          paidOrders.reduce((sum, o) => sum + Number(o.amount || 0), 0) /
            paidOrders.length
        )
      : 0;

  const conversionRate =
    customers.length > 0
      ? Math.round((paidOrders.length / customers.length) * 100)
      : 0;

  return (
    <div>
      <h1 className="page-title">Analytics</h1>
      <p className="page-subtitle">
        {ownerId ? `目前帳號：${ownerId}` : "請帶入 ownerId"}
      </p>

      <div style={{ marginBottom: 20 }}>
        <button
          className="btn-pro"
          onClick={() => window.location.reload()}
        >
          🔄 重新整理
        </button>
      </div>

      {/* KPI */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "20px",
          marginBottom: "30px"
        }}
      >
        <div className="glass-card metric-card glow-border">
          <div className="metric-label">總營收</div>
          <div className="metric-value">
            {loading ? "..." : `$${revenue.total.toLocaleString()}`}
          </div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">本月營收</div>
          <div className="metric-value">
            {loading ? "..." : `$${revenue.monthly.toLocaleString()}`}
          </div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">平均客單價</div>
          <div className="metric-value">
            {loading ? "..." : `$${avgOrderValue.toLocaleString()}`}
          </div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">轉換率</div>
          <div className="metric-value">
            {loading ? "..." : `${conversionRate}%`}
          </div>
        </div>
      </div>

      {/* 成交來源分析 */}
      <div className="glass-card glow-border" style={{ padding: 20 }}>
        <h3 style={{ marginTop: 0 }}>成交來源分析</h3>

        <div style={{ lineHeight: 2 }}>
          {["telegram", "ig", "line", "fb"].map((source) => {
            const count = paidOrders.filter(
              (o) => (o.source || "").toLowerCase() === source
            ).length;

            return (
              <div key={source}>
                {source.toUpperCase()}：{count} 筆
              </div>
            );
          })}
        </div>
      </div>

      {/* AI 分析 */}
      <div
        className="glass-card glow-border"
        style={{ padding: 20, marginTop: 20 }}
      >
        <h3 style={{ marginTop: 0 }}>AI 客戶分析</h3>

        <div style={{ lineHeight: 2 }}>
          <div>
            成交客戶：
            {customers.filter((c) => c.level === "成交").length}
          </div>

          <div>
            猶豫客戶：
            {customers.filter((c) => c.level === "猶豫").length}
          </div>

          <div>
            冷客：
            {
              customers.filter(
                (c) => c.level !== "成交" && c.level !== "猶豫"
              ).length
            }
          </div>
        </div>
      </div>
    </div>
  );
}