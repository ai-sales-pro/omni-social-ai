export default function Bank() {
  return (
    <div className="glass">
      <h1 className="neon-text">Bank</h1>
      <p>銀行設定頁面</p>
    </div>
  );
}