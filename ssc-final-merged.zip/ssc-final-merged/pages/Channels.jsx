import React, { useEffect, useMemo, useState } from "react";

const CHANNELS = [
  {
    key: "instagram",
    title: "Instagram",
    subtitle: "綁定 Instagram 專業帳號",
    desc: "讓 AI 自動回覆 IG 私訊、判斷購買意圖、推付款。",
    badge: "熱門"
  },
  {
    key: "facebook",
    title: "Facebook Messenger",
    subtitle: "綁定 Facebook 粉專",
    desc: "讓 AI 接手 Messenger 對話、自動成交與追單。",
    badge: "必接"
  },
  {
    key: "telegram",
    title: "Telegram",
    subtitle: "綁定 Telegram Bot",
    desc: "快速啟用 Telegram 自動回覆與訂單推進。",
    badge: "最快"
  },
  {
    key: "whatsapp",
    title: "WhatsApp",
    subtitle: "綁定 WhatsApp Business",
    desc: "接住國際客戶，自動回覆與銷售流程。",
    badge: "國際"
  },
  {
    key: "line",
    title: "LINE",
    subtitle: "綁定 LINE Official Account",
    desc: "適合台灣市場，讓 AI 自動聊天與成交。",
    badge: "台灣"
  }
];

const DEFAULT_CONNECTED = {
  instagram: false,
  facebook: false,
  telegram: false,
  whatsapp: false,
  line: false
};

export default function Channels() {
  const [ownerId, setOwnerId] = useState("");
  const [connected, setConnected] = useState(DEFAULT_CONNECTED);

  const [loadingPage, setLoadingPage] = useState(true);
  const [savingKey, setSavingKey] = useState("");
  const [notice, setNotice] = useState("");

  const [industry, setIndustry] = useState("fortune");
  const [productName, setProductName] = useState("AI 自動成交方案");
  const [productPrice, setProductPrice] = useState("3000");
  const [autoReply, setAutoReply] = useState(true);
  const [autoPush, setAutoPush] = useState(true);
  const [multiLanguage, setMultiLanguage] = useState(true);

  const connectedCount = useMemo(() => {
    return Object.values(connected).filter(Boolean).length;
  }, [connected]);

  useEffect(() => {
    async function bootstrap() {
      try {
        const localOwnerId = localStorage.getItem("ownerId") || "system";
        setOwnerId(localOwnerId);

        await Promise.all([
          loadAISettings(localOwnerId),
          loadConnections(localOwnerId)
        ]);
      } catch (err) {
        console.error(err);
        setNotice("⚠️ 讀取資料失敗，請重新整理");
      } finally {
        setLoadingPage(false);
      }
    }

    bootstrap();
  }, []);

  async function loadAISettings(localOwnerId) {
    try {
      const res = await fetch(`/api/ai-settings/${encodeURIComponent(localOwnerId)}`);
      const data = await res.json();

      if (!data?.ok || !data?.settings) return;

      const settings = data.settings;

      if (settings.industry) setIndustry(settings.industry);
      if (settings.product_name) setProductName(settings.product_name);
      if (settings.product_price !== undefined && settings.product_price !== null) {
        setProductPrice(String(settings.product_price));
      }

      if (typeof settings.auto_reply === "boolean") {
        setAutoReply(settings.auto_reply);
      }

      if (typeof settings.auto_payment_push === "boolean") {
        setAutoPush(settings.auto_payment_push);
      }

      if (settings.primary_language === "auto") {
        setMultiLanguage(true);
      } else if (settings.primary_language) {
        setMultiLanguage(false);
      }
    } catch (err) {
      console.error("loadAISettings error:", err);
    }
  }

  async function loadConnections(localOwnerId) {
    try {
      const res = await fetch(
        `/api/channel-connections/${encodeURIComponent(localOwnerId)}`
      );

      if (!res.ok) return;

      const data = await res.json();
      if (!data?.ok || !Array.isArray(data.connections)) return;

      const next = { ...DEFAULT_CONNECTED };

      for (const item of data.connections) {
        if (item?.platform && next[item.platform] !== undefined) {
          next[item.platform] = item.status === "connected";
        }
      }

      setConnected(next);
    } catch (err) {
      console.error("loadConnections error:", err);
    }
  }

  async function handleConnect(channelKey) {
    try {
      setSavingKey(channelKey);
      setNotice("");

      const localOwnerId = ownerId || localStorage.getItem("ownerId") || "system";

      if (!localOwnerId) {
        setNotice("❌ 找不到使用者，請重新登入");
        return;
      }

      if (channelKey === "facebook" || channelKey === "instagram") {
        window.location.href = `/api/connect/meta/start?ownerId=${encodeURIComponent(
          localOwnerId
        )}&platform=${encodeURIComponent(channelKey)}`;
        return;
      }

      if (channelKey === "telegram") {
        setNotice("👉 Telegram 真綁定下一步再接，目前先保留 UI 與設定邏輯");
        return;
      }

      if (channelKey === "whatsapp") {
        setNotice("👉 WhatsApp 真綁定下一步再接，目前先保留 UI 與設定邏輯");
        return;
      }

      if (channelKey === "line") {
        setNotice("👉 LINE 真綁定下一步再接，目前先保留 UI 與設定邏輯");
        return;
      }
    } finally {
      setSavingKey("");
    }
  }

  async function handleDisconnect(channelKey) {
    try {
      setSavingKey(channelKey);
      setNotice("");

      const localOwnerId = ownerId || localStorage.getItem("ownerId") || "system";

      const res = await fetch("/api/channel-connections/disconnect", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ownerId: localOwnerId,
          platform: channelKey
        })
      });

      const data = await res.json().catch(() => null);

      if (!res.ok || !data?.ok) {
        setNotice("❌ 解除綁定失敗");
        return;
      }

      setConnected((prev) => ({
        ...prev,
        [channelKey]: false
      }));

      setNotice(`✅ ${channelKey} 已解除綁定`);
    } catch (err) {
      console.error(err);
      setNotice("❌ 解除綁定失敗");
    } finally {
      setSavingKey("");
    }
  }

  async function handleSaveSettings() {
    try {
      setSavingKey("settings");
      setNotice("");

      const localOwnerId = ownerId || localStorage.getItem("ownerId") || "system";

      const aiRes = await fetch("/api/ai-settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ownerId: localOwnerId,
          industry,
          productName,
          productPrice: Number(productPrice || 0),
          autoReply,
          autoPaymentPush: autoPush,
          autoMode: true,
          primaryLanguage: multiLanguage ? "auto" : "zh-TW"
        })
      });

      const industryRes = await fetch("/api/industry-profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          ownerId: localOwnerId,
          industry,
          offerName: productName,
          offerPrice: Number(productPrice || 0),
          closingStyle: "balanced",
          multilingual: multiLanguage,
          primaryLanguage: multiLanguage ? "auto" : "zh-TW",
          customSalesPrompt: ""
        })
      });

      const aiData = await aiRes.json().catch(() => null);
      const industryData = await industryRes.json().catch(() => null);

      if (!aiRes.ok || aiData?.ok === false) {
        setNotice("❌ AI 設定儲存失敗");
        return;
      }

      if (!industryRes.ok || industryData?.ok === false) {
        setNotice("⚠️ AI 設定已存，但行業銷售設定儲存失敗");
        return;
      }

      setNotice("✅ 設定已儲存並啟用");
    } catch (err) {
      console.error(err);
      setNotice("❌ 儲存失敗，請再試一次");
    } finally {
      setSavingKey("");
    }
  }

  if (loadingPage) {
    return (
      <div style={styles.page}>
        <div style={styles.loadingCard}>載入 Channels 中...</div>
      </div>
    );
  }

  return (
    <div style={styles.page}>
      <div style={styles.hero}>
        <div>
          <div style={styles.eyebrow}>CHANNEL BINDING</div>
          <h1 style={styles.title}>一鍵綁定你的銷售渠道</h1>
          <p style={styles.desc}>
            綁定你的 IG、FB、Telegram、LINE、WhatsApp，
            讓 AI 直接幫你自動回覆、自動成交、自動推付款。
          </p>

          <div style={styles.ownerLine}>
            目前帳號：<span style={styles.ownerValue}>{ownerId || "未登入"}</span>
          </div>

          {notice ? <div style={styles.notice}>{notice}</div> : null}
        </div>

        <div style={styles.heroStatCard}>
          <div style={styles.statLabel}>已綁定渠道</div>
          <div style={styles.statValue}>{connectedCount}</div>
          <div style={styles.statSub}>渠道越多，成交入口越多</div>
        </div>
      </div>

      <div style={styles.layout}>
        <div style={styles.leftCol}>
          <div style={styles.sectionCard}>
            <div style={styles.sectionHead}>
              <div style={styles.sectionTitle}>平台綁定</div>
              <div style={styles.sectionHint}>Facebook / Instagram 可先做真綁定</div>
            </div>

            <div style={styles.channelGrid}>
              {CHANNELS.map((item) => {
                const isConnected = connected[item.key];

                return (
                  <div key={item.key} style={styles.channelCard}>
                    <div style={styles.channelTop}>
                      <div>
                        <div style={styles.channelTitle}>{item.title}</div>
                        <div style={styles.channelSubtitle}>{item.subtitle}</div>
                      </div>

                      <div
                        style={{
                          ...styles.badge,
                          ...(isConnected ? styles.badgeConnected : {})
                        }}
                      >
                        {isConnected ? "已綁定" : item.badge}
                      </div>
                    </div>

                    <div style={styles.channelDesc}>{item.desc}</div>

                    <div style={styles.channelActionRow}>
                      <button
                        style={{
                          ...styles.channelBtn,
                          ...(isConnected ? styles.channelBtnConnected : {})
                        }}
                        onClick={() =>
                          isConnected
                            ? handleDisconnect(item.key)
                            : handleConnect(item.key)
                        }
                      >
                        {savingKey === item.key
                          ? "處理中..."
                          : isConnected
                          ? "解除綁定"
                          : "立即綁定"}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div style={styles.rightCol}>
          <div style={styles.sectionCard}>
            <div style={styles.sectionTitle}>AI 銷售設定</div>

            <div style={styles.formGroup}>
              <label style={styles.label}>行業類型</label>
              <select
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                style={styles.select}
              >
                <option value="fortune">命理 / 靈性 / 法事</option>
                <option value="beauty">美容 / 醫美</option>
                <option value="coach">顧問 / 教練</option>
                <option value="ecommerce">電商 / 商品</option>
                <option value="real_estate">房仲 / 業務</option>
                <option value="custom">其他 / 自訂</option>
              </select>
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>主要商品名稱</label>
              <input
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                style={styles.input}
                placeholder="例如：和合挽回法事"
              />
            </div>

            <div style={styles.formGroup}>
              <label style={styles.label}>主要銷售金額</label>
              <input
                value={productPrice}
                onChange={(e) => setProductPrice(e.target.value)}
                style={styles.input}
                placeholder="例如：18000"
              />
            </div>

            <div style={styles.toggleRow}>
              <Toggle
                label="AI 自動回覆"
                checked={autoReply}
                onChange={() => setAutoReply(!autoReply)}
              />
              <Toggle
                label="AI 自動推付款"
                checked={autoPush}
                onChange={() => setAutoPush(!autoPush)}
              />
              <Toggle
                label="多語言自動回覆"
                checked={multiLanguage}
                onChange={() => setMultiLanguage(!multiLanguage)}
              />
            </div>

            <button style={styles.saveBtn} onClick={handleSaveSettings}>
              {savingKey === "settings" ? "儲存中..." : "儲存並啟用 AI"}
            </button>
          </div>

          <div style={styles.sectionCard}>
            <div style={styles.sectionTitle}>啟用後會發生什麼？</div>

            <div style={styles.stepList}>
              <div style={styles.stepItem}>1. 客戶從你的平台私訊進來</div>
              <div style={styles.stepItem}>2. AI 自動判斷語言與購買意圖</div>
              <div style={styles.stepItem}>3. 套用你的行業話術與商品價格</div>
              <div style={styles.stepItem}>4. 自動回覆、自動推付款、自動追單</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Toggle({ label, checked, onChange }) {
  return (
    <div style={styles.toggleItem}>
      <div style={styles.toggleLabel}>{label}</div>
      <button
        type="button"
        onClick={onChange}
        style={{
          ...styles.toggleBtn,
          ...(checked ? styles.toggleBtnOn : {})
        }}
      >
        <div
          style={{
            ...styles.toggleDot,
            ...(checked ? styles.toggleDotOn : {})
          }}
        />
      </button>
    </div>
  );
}

const styles = {
  page: {
    display: "grid",
    gap: 20
  },

  loadingCard: {
    borderRadius: 24,
    padding: 24,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#fff"
  },

  hero: {
    display: "grid",
    gridTemplateColumns: "1.2fr 0.8fr",
    gap: 18,
    alignItems: "stretch"
  },

  eyebrow: {
    fontSize: 12,
    letterSpacing: "0.14em",
    color: "rgba(232,221,255,0.62)",
    marginBottom: 10
  },

  title: {
    margin: 0,
    fontSize: 34,
    fontWeight: 900,
    letterSpacing: "-0.04em"
  },

  desc: {
    marginTop: 12,
    maxWidth: 760,
    color: "rgba(235,225,255,0.78)",
    lineHeight: 1.9
  },

  ownerLine: {
    marginTop: 14,
    color: "rgba(235,225,255,0.68)",
    fontSize: 13
  },

  ownerValue: {
    color: "#fff",
    fontWeight: 700
  },

  notice: {
    marginTop: 14,
    padding: "12px 14px",
    borderRadius: 14,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#fff"
  },

  heroStatCard: {
    borderRadius: 24,
    padding: 22,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    boxShadow: "0 0 30px rgba(140,90,255,0.12)"
  },

  statLabel: {
    fontSize: 13,
    color: "rgba(235,225,255,0.66)"
  },

  statValue: {
    marginTop: 10,
    fontSize: 52,
    fontWeight: 900,
    lineHeight: 1
  },

  statSub: {
    marginTop: 12,
    color: "rgba(235,225,255,0.72)",
    lineHeight: 1.7
  },

  layout: {
    display: "grid",
    gridTemplateColumns: "1.2fr 0.8fr",
    gap: 20
  },

  leftCol: {
    display: "grid",
    gap: 20
  },

  rightCol: {
    display: "grid",
    gap: 20
  },

  sectionCard: {
    borderRadius: 26,
    padding: 22,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    boxShadow:
      "0 16px 44px rgba(0,0,0,0.22), 0 0 24px rgba(140,90,255,0.08)"
  },

  sectionHead: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
    marginBottom: 18,
    flexWrap: "wrap"
  },

  sectionTitle: {
    fontSize: 20,
    fontWeight: 800,
    marginBottom: 18
  },

  sectionHint: {
    fontSize: 12,
    color: "rgba(235,225,255,0.62)"
  },

  channelGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: 14
  },

  channelCard: {
    borderRadius: 20,
    padding: 18,
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)"
  },

  channelTop: {
    display: "flex",
    justifyContent: "space-between",
    gap: 12,
    alignItems: "flex-start"
  },

  channelTitle: {
    fontSize: 18,
    fontWeight: 800
  },

  channelSubtitle: {
    marginTop: 6,
    fontSize: 13,
    color: "rgba(235,225,255,0.62)"
  },

  channelDesc: {
    marginTop: 14,
    lineHeight: 1.8,
    color: "rgba(235,225,255,0.78)",
    minHeight: 70
  },

  channelActionRow: {
    marginTop: 16
  },

  badge: {
    padding: "7px 10px",
    borderRadius: 999,
    fontSize: 11,
    fontWeight: 700,
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.08)",
    whiteSpace: "nowrap"
  },

  badgeConnected: {
    background: "rgba(80,255,160,0.10)",
    border: "1px solid rgba(80,255,160,0.18)",
    color: "#d8ffe9"
  },

  channelBtn: {
    width: "100%",
    padding: "13px 14px",
    borderRadius: 14,
    border: "1px solid rgba(198,160,255,0.34)",
    background:
      "linear-gradient(135deg, rgba(157,92,255,0.95), rgba(95,124,255,0.95))",
    color: "#fff",
    fontWeight: 800,
    cursor: "pointer"
  },

  channelBtnConnected: {
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.10)"
  },

  formGroup: {
    display: "grid",
    gap: 8,
    marginBottom: 14
  },

  label: {
    fontSize: 13,
    color: "rgba(235,225,255,0.68)"
  },

  input: {
    width: "100%",
    padding: "13px 14px",
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.05)",
    color: "#fff",
    outline: "none",
    boxSizing: "border-box"
  },

  select: {
    width: "100%",
    padding: "13px 14px",
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.05)",
    color: "#fff",
    outline: "none",
    boxSizing: "border-box"
  },

  toggleRow: {
    display: "grid",
    gap: 12,
    marginTop: 8,
    marginBottom: 18
  },

  toggleItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "12px 14px",
    borderRadius: 16,
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)"
  },

  toggleLabel: {
    fontSize: 14,
    fontWeight: 600
  },

  toggleBtn: {
    width: 54,
    height: 30,
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.08)",
    position: "relative",
    cursor: "pointer"
  },

  toggleBtnOn: {
    background:
      "linear-gradient(135deg, rgba(157,92,255,0.95), rgba(95,124,255,0.95))"
  },

  toggleDot: {
    width: 22,
    height: 22,
    borderRadius: "50%",
    background: "#fff",
    position: "absolute",
    top: 3,
    left: 4,
    transition: "all 0.25s ease"
  },

  toggleDotOn: {
    left: 26
  },

  saveBtn: {
    width: "100%",
    padding: "14px 16px",
    borderRadius: 16,
    border: "1px solid rgba(198,160,255,0.34)",
    background:
      "linear-gradient(135deg, rgba(157,92,255,0.95), rgba(95,124,255,0.95))",
    color: "#fff",
    fontWeight: 800,
    cursor: "pointer",
    boxShadow: "0 0 26px rgba(140,90,255,0.20)"
  },

  stepList: {
    display: "grid",
    gap: 12
  },

  stepItem: {
    padding: "12px 14px",
    borderRadius: 16,
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)",
    lineHeight: 1.8,
    color: "rgba(235,225,255,0.82)"
  }
};

