import React, { useEffect, useState } from "react";

function getOwnerId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("ownerId") || "";
}

function levelStyle(level) {
  if (level === "成交") {
    return {
      background: "rgba(38, 211, 138, 0.16)",
      border: "1px solid rgba(38, 211, 138, 0.28)",
      color: "#7CFFBF"
    };
  }

  if (level === "猶豫") {
    return {
      background: "rgba(255, 204, 102, 0.14)",
      border: "1px solid rgba(255, 204, 102, 0.22)",
      color: "#FFD978"
    };
  }

  return {
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#EDE4FF"
  };
}

export default function Customers() {
  const ownerId = getOwnerId();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadCustomers() {
      if (!ownerId) {
        setLoading(false);
        return;
      }

      try {
        const res = await fetch(`/api/customers/${ownerId}`);
        const data = await res.json();

        if (data.ok) {
          setCustomers(data.customers || []);
        }
      } catch (err) {
        console.error("load customers error:", err);
      } finally {
        setLoading(false);
      }
    }

    loadCustomers();
  }, [ownerId]);

  const dealCount = customers.filter((c) => c.level === "成交").length;
  const warmCount = customers.filter((c) => c.level === "猶豫").length;
  const otherCount = customers.filter(
    (c) => c.level !== "成交" && c.level !== "猶豫"
  ).length;

  return (
    <div>
      <h1 className="page-title">客戶管理</h1>
      <p className="page-subtitle">
        {ownerId ? `目前帳號：${ownerId}` : "請帶入 ownerId 才能讀取真資料"}
      </p>

      <div style={{ marginBottom: 20 }}>
        <button className="btn-pro" onClick={() => window.location.reload()}>
          🔄 重新整理資料
        </button>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "20px",
          marginBottom: "30px"
        }}
      >
        <div className="glass-card metric-card glow-border">
          <div className="metric-label">客戶總數</div>
          <div className="metric-value">{loading ? "..." : customers.length}</div>
          <div className="metric-trend">全部名單</div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">成交客戶</div>
          <div className="metric-value">{loading ? "..." : dealCount}</div>
          <div className="metric-trend">高價值名單</div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">猶豫客戶</div>
          <div className="metric-value">{loading ? "..." : warmCount}</div>
          <div className="metric-trend">可追單</div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">興趣 / 冷客</div>
          <div className="metric-value">{loading ? "..." : otherCount}</div>
          <div className="metric-trend">待培養</div>
        </div>
      </div>

      <div className="glass-card glow-border" style={{ padding: 22 }}>
        <h3 style={{ marginTop: 0, marginBottom: 16 }}>客戶清單</h3>

        <table className="panel-table">
          <thead>
            <tr>
              <th>Chat ID</th>
              <th>等級</th>
              <th>意圖</th>
              <th>情緒</th>
              <th>最後訊息</th>
              <th>更新時間</th>
            </tr>
          </thead>
          <tbody>
            {customers.map((customer) => (
              <tr key={`${customer.owner_id}-${customer.chat_id}`}>
                <td>{customer.chat_id}</td>
                <td>
                  <span
                    className="status-pill"
                    style={levelStyle(customer.level)}
                  >
                    {customer.level || "-"}
                  </span>
                </td>
                <td>{customer.intent || "-"}</td>
                <td>{customer.emotion || "-"}</td>
                <td>{customer.last_message || "-"}</td>
                <td>
                  {customer.updated_at
                    ? new Date(customer.updated_at).toLocaleString()
                    : "-"}
                </td>
              </tr>
            ))}

            {!loading && customers.length === 0 && (
              <tr>
                <td colSpan="6">目前沒有客戶資料</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}