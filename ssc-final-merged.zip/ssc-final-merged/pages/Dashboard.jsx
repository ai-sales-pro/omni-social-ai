import React, { useEffect, useState } from "react";

function getOwnerId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("ownerId") || "";
}

export default function Dashboard() {
  const ownerId = getOwnerId();

  const [revenue, setRevenue] = useState({ total: 0, monthly: 0 });
  const [customers, setCustomers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      if (!ownerId) {
        setLoading(false);
        return;
      }

      try {
        const [revenueRes, customersRes, ordersRes] = await Promise.all([
          fetch(`/api/revenue/${ownerId}`),
          fetch(`/api/customers/${ownerId}`),
          fetch(`/api/orders/${ownerId}`)
        ]);

        const revenueData = await revenueRes.json();
        const customersData = await customersRes.json();
        const ordersData = await ordersRes.json();

        if (revenueData.ok) {
          setRevenue({
            total: revenueData.total || 0,
            monthly: revenueData.monthly || 0
          });
        }

        if (customersData.ok) {
          setCustomers(customersData.customers || []);
        }

        if (ordersData.ok) {
          setOrders(ordersData.orders || []);
        }
      } catch (err) {
        console.error("load dashboard data error:", err);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [ownerId]);

  const paidOrders = orders.filter((o) => o.status === "paid");
  const pendingOrders = orders.filter((o) => o.status === "pending");

  const conversionRate =
    customers.length > 0
      ? Math.round((paidOrders.length / customers.length) * 100)
      : 0;

  return (
    <div>
      <h1 className="page-title">老闆專用控制台</h1>
      <p className="page-subtitle">
        {ownerId ? `目前帳號：${ownerId}` : "請帶入 ownerId 才能讀取真資料"}
      </p>

      <div style={{ marginBottom: 20 }}>
        <button className="btn-pro" onClick={() => window.location.reload()}>
          🔄 重新整理資料
        </button>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "20px",
          marginBottom: "24px"
        }}
      >
        <div className="glass-card metric-card glow-border">
          <div className="metric-label">總訂閱收入</div>
          <div className="metric-value">
            {loading ? "..." : `$${Number(revenue.total || 0).toLocaleString()}`}
          </div>
          <div className="metric-trend">全部已付款訂單</div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">訂閱客戶總數</div>
          <div className="metric-value">
            {loading ? "..." : customers.length}
          </div>
          <div className="metric-trend">全部名單</div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">今日新成交</div>
          <div className="metric-value">
            {loading ? "..." : paidOrders.length}
          </div>
          <div className="metric-trend">已付款訂單數</div>
        </div>

        <div className="glass-card metric-card glow-border">
          <div className="metric-label">成交轉換率</div>
          <div className="metric-value">
            {loading ? "..." : `${conversionRate}%`}
          </div>
          <div className="metric-trend">已付款 / 客戶數</div>
        </div>
      </div>

      <div className="glass-card glow-border" style={{ padding: 22, marginBottom: 24 }}>
        <h3 style={{ marginTop: 0, marginBottom: 16 }}>訂閱客戶列表</h3>

        <table className="panel-table">
          <thead>
            <tr>
              <th>客戶</th>
              <th>方案</th>
              <th>金額</th>
              <th>狀態</th>
              <th>來源平台</th>
            </tr>
          </thead>
          <tbody>
            {orders.slice(0, 5).map((order) => (
              <tr key={order.id}>
                <td>{order.customer_name || "客戶"}</td>
                <td>{order.plan || "-"}</td>
                <td>${Number(order.amount || 0).toLocaleString()}</td>
                <td>
                  <span className="status-pill">
                    {order.status === "paid" ? "已付款" : "待付款"}
                  </span>
                </td>
                <td>{order.source || "-"}</td>
              </tr>
            ))}

            {!loading && orders.length === 0 && (
              <tr>
                <td colSpan="5">目前沒有訂單資料</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1.2fr 1fr",
          gap: 20
        }}
      >
        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <h3 style={{ marginTop: 0 }}>金流總覽</h3>
          <div style={{ display: "flex", gap: 24, flexWrap: "wrap", marginBottom: 12 }}>
            <div>
              <div className="metric-label">總收款金額</div>
              <div style={{ fontSize: 36, fontWeight: 800 }}>
                {loading ? "..." : `$${Number(revenue.total || 0).toLocaleString()}`}
              </div>
            </div>
            <div>
              <div className="metric-label">本月收入</div>
              <div style={{ fontSize: 28, fontWeight: 800 }}>
                {loading ? "..." : `$${Number(revenue.monthly || 0).toLocaleString()}`}
              </div>
            </div>
          </div>
          <div className="metric-trend">真實資料同步中</div>
        </div>

        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <h3 style={{ marginTop: 0 }}>AI 系統狀態</h3>
          <div style={{ lineHeight: 2 }}>
            <div>AI 自動成交系統：運作中</div>
            <div>自動回覆機器人：運作中</div>
            <div>成交預測模型：分析中</div>
            <div>多語言偵測系統：運作中</div>
          </div>
        </div>
      </div>
    </div>
  );
}