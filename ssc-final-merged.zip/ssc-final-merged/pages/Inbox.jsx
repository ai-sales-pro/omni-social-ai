import React, { useState } from "react";

const conversations = [
  {
    id: 1,
    name: "Amy Lin",
    platform: "IG",
    status: "高成交潛力",
    last: "多少錢？我想快點開始",
    time: "2m ago",
    messages: [
      { role: "customer", text: "你好，我想了解一下方案" },
      { role: "ai", text: "可以，我先幫你看一下，你比較想要快速成交版還是入門版？" },
      { role: "customer", text: "多少錢？我想快點開始" },
      { role: "ai", text: "你這個狀況比較適合直接走 Pro 方案，我幫你整理好了。" }
    ]
  },
  {
    id: 2,
    name: "David Chen",
    platform: "LINE",
    status: "等待跟進",
    last: "可以今天付款嗎",
    time: "8m ago",
    messages: [
      { role: "customer", text: "我想今天開始，可以嗎？" },
      { role: "ai", text: "可以，我幫你安排最快的方式，你今天就能啟動。" },
      { role: "customer", text: "可以今天付款嗎" }
    ]
  },
  {
    id: 3,
    name: "John Lee",
    platform: "FB",
    status: "VIP 客戶",
    last: "我想直接做高級版",
    time: "15m ago",
    messages: [
      { role: "customer", text: "我想直接做高級版" },
      { role: "ai", text: "可以，這邊直接幫你走 Elite 方案會最適合。" }
    ]
  }
];

function statusStyle(status) {
  if (status === "高成交潛力") {
    return {
      background: "rgba(255, 122, 89, 0.14)",
      border: "1px solid rgba(255, 122, 89, 0.22)",
      color: "#FFB199"
    };
  }

  if (status === "VIP 客戶") {
    return {
      background: "rgba(111, 92, 255, 0.16)",
      border: "1px solid rgba(111, 92, 255, 0.24)",
      color: "#CBB8FF"
    };
  }

  return {
    background: "rgba(255,255,255,0.06)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#EDE4FF"
  };
}

export default function Inbox() {
  const [selectedId, setSelectedId] = useState(1);
  const selected = conversations.find((c) => c.id === selectedId) || conversations[0];

  return (
    <div>
      <h1 className="page-title">AI 成交 Inbox</h1>
      <p className="page-subtitle">AI 對話工作台 ・ 客戶訊息 ・ 自動成交跟進</p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "320px 1fr",
          gap: 20
        }}
      >
        {/* 左邊對話列表 */}
        <div className="glass-card glow-border" style={{ padding: 16 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 10,
              marginBottom: 14
            }}
          >
            <h3 style={{ margin: 0 }}>對話列表</h3>
            <span className="status-pill">即時</span>
          </div>

          <input
            className="input-pro"
            placeholder="搜尋客戶 / 平台"
            style={{ width: "100%", marginBottom: 14 }}
          />

          <div style={{ display: "grid", gap: 10 }}>
            {conversations.map((item) => {
              const active = item.id === selectedId;

              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedId(item.id)}
                  style={{
                    borderRadius: 18,
                    padding: 14,
                    cursor: "pointer",
                    border: active
                      ? "1px solid rgba(205,165,255,0.34)"
                      : "1px solid rgba(255,255,255,0.08)",
                    background: active
                      ? "linear-gradient(180deg, rgba(89,52,170,0.26), rgba(28,18,54,0.78))"
                      : "rgba(255,255,255,0.03)",
                    boxShadow: active
                      ? "0 0 28px rgba(168,85,247,0.16)"
                      : "none",
                    transition: "all 0.25s ease"
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      gap: 10,
                      marginBottom: 8
                    }}
                  >
                    <div style={{ fontWeight: 700 }}>{item.name}</div>
                    <div style={{ fontSize: 12, opacity: 0.62 }}>{item.time}</div>
                  </div>

                  <div style={{ fontSize: 12, opacity: 0.72, marginBottom: 8 }}>
                    {item.platform}
                  </div>

                  <div
                    style={{
                      fontSize: 13,
                      color: "rgba(245,237,255,0.82)",
                      marginBottom: 10
                    }}
                  >
                    {item.last}
                  </div>

                  <span className="status-pill" style={statusStyle(item.status)}>
                    {item.status}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* 右邊聊天視窗 */}
        <div className="glass-card glow-border" style={{ padding: 18 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 12,
              marginBottom: 16,
              flexWrap: "wrap"
            }}
          >
            <div>
              <h3 style={{ margin: 0 }}>{selected.name}</h3>
              <div style={{ fontSize: 13, opacity: 0.68, marginTop: 6 }}>
                {selected.platform} ・ AI 自動成交已啟用
              </div>
            </div>

            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <span className="status-pill" style={statusStyle(selected.status)}>
                {selected.status}
              </span>
              <button className="btn-pro">推送付款連結</button>
            </div>
          </div>

          <div
            className="glass"
            style={{
              minHeight: 360,
              padding: 18,
              marginBottom: 16,
              display: "flex",
              flexDirection: "column",
              gap: 12
            }}
          >
            {selected.messages.map((msg, index) => (
              <div
                key={index}
                style={{
                  alignSelf: msg.role === "ai" ? "flex-end" : "flex-start",
                  maxWidth: "78%",
                  background:
                    msg.role === "ai"
                      ? "linear-gradient(135deg, rgba(140,90,255,0.24), rgba(99,102,241,0.16))"
                      : "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 18,
                  padding: "12px 14px",
                  color: "#F5EDFF",
                  lineHeight: 1.7
                }}
              >
                <div
                  style={{
                    fontSize: 11,
                    opacity: 0.6,
                    marginBottom: 6
                  }}
                >
                  {msg.role === "ai" ? "AI" : "客戶"}
                </div>
                {msg.text}
              </div>
            ))}
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr auto",
              gap: 12,
              alignItems: "center"
            }}
          >
            <input
              className="input-pro"
              placeholder="輸入要回覆的訊息…"
              style={{ width: "100%" }}
            />
            <button className="btn-pro">送出回覆</button>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: 12,
              marginTop: 16
            }}
          >
            <div className="glass" style={{ padding: 14 }}>
              <div className="metric-label">AI 建議</div>
              <div style={{ fontSize: 14, lineHeight: 1.7 }}>
                建議直接推 Pro 方案並附付款連結
              </div>
            </div>

            <div className="glass" style={{ padding: 14 }}>
              <div className="metric-label">下一步動作</div>
              <div style={{ fontSize: 14, lineHeight: 1.7 }}>
                2 小時內若未付款，自動提醒一次
              </div>
            </div>

            <div className="glass" style={{ padding: 14 }}>
              <div className="metric-label">客戶價值</div>
              <div style={{ fontSize: 14, lineHeight: 1.7 }}>
                高成交潛力，建議優先跟進
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}