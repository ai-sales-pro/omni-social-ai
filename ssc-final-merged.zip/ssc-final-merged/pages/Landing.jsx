import React, { useEffect, useRef, useState } from "react";

const STRIPE_LINKS = {
  starter: "https://buy.stripe.com/dRm4gs7E73W7fJ8eQz0kE0f",
  growth: "https://buy.stripe.com/3cI14ge2v8cn54uaAj0kE0g",
  elite: "https://buy.stripe.com/4gM9AMf6zdwHbsSbEn0kE0h"
};

export default function Landing({ onLogin, onEnterApp }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState("growth");

  const [messages, setMessages] = useState([
    { role: "ai", text: "你現在是想讓 AI 幫你自動成交，還是先了解？" }
  ]);

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  /* =============================
     AI聊天
  ============================= */

  async function sendMessage() {
    if (!input.trim()) return;

    const text = input;

    setMessages((prev) => [...prev, { role: "user", text }]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/platform-ai-chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ message: text })
      });

      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        { role: "ai", text: data.reply || "我幫你整理好了。" }
      ]);

      // 👉 自動打開訂閱抽屜
      if (
        data.analysis?.intent === "pricing" ||
        data.analysis?.intent === "buy" ||
        data.analysis?.level === "high"
      ) {
        setTimeout(() => setDrawerOpen(true), 400);
      }

      if (data.plan) {
        setSelectedPlan(data.plan);
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "ai", text: "剛剛有點問題，再試一次。" }
      ]);
    }

    setLoading(false);
  }

  /* =============================
     UI
  ============================= */

  return (
    <div style={styles.page}>
      {/* ===== 左側 ===== */}
      <div style={styles.left}>
        <h1 style={styles.title}>
          AI 自動成交系統
        </h1>

        <p style={styles.desc}>
          不用再回訊息、不用再慢慢聊  
          AI 直接幫你 → 回覆 / 成交 / 收錢
        </p>

        <div style={styles.btnRow}>
          <button style={styles.mainBtn} onClick={() => setDrawerOpen(true)}>
            開始使用
          </button>

          <button style={styles.subBtn} onClick={onLogin}>
            登入
          </button>
        </div>

        {/* ===== AI聊天 ===== */}
        <div style={styles.chat}>
          <div style={styles.chatInner}>
            {messages.map((m, i) => (
              <div
                key={i}
                style={{
                  ...styles.msg,
                  alignSelf:
                    m.role === "user" ? "flex-end" : "flex-start",
                  background:
                    m.role === "user"
                      ? "rgba(120,80,255,0.3)"
                      : "rgba(255,255,255,0.08)"
                }}
              >
                {m.text}
              </div>
            ))}

            {loading && <div>AI thinking...</div>}
            <div ref={endRef} />
          </div>

          <div style={styles.inputRow}>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="問：價格 / 功能 / 適合我嗎"
              style={styles.input}
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            />

            <button style={styles.sendBtn} onClick={sendMessage}>
              送出
            </button>
          </div>
        </div>
      </div>

      {/* ===== 右側視覺 ===== */}
      <div style={styles.right}>
        <div style={styles.card}>
          <h2>AI Revenue Engine</h2>
          <p>24/7 自動成交系統</p>
        </div>
      </div>

      {/* ===== 背景遮罩 ===== */}
      {drawerOpen && (
        <div style={styles.overlay} onClick={() => setDrawerOpen(false)} />
      )}

      {/* ===== 訂閱抽屜 ===== */}
      <div
        style={{
          ...styles.drawer,
          transform: drawerOpen ? "translateY(0)" : "translateY(100%)"
        }}
      >
        <div style={styles.drawerTitle}>選擇方案</div>

        <div style={styles.planRow}>
          {["starter", "growth", "elite"].map((plan) => (
            <div
              key={plan}
              style={{
                ...styles.plan,
                border:
                  selectedPlan === plan
                    ? "1px solid #9d5cff"
                    : "1px solid rgba(255,255,255,0.1)"
              }}
              onClick={() => setSelectedPlan(plan)}
            >
              <h3>{plan}</h3>
              <button
                style={styles.buyBtn}
                onClick={() => window.location.href = STRIPE_LINKS[plan]}
              >
                購買
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* =============================
   STYLE
============================= */

const styles = {
  page: {
    display: "flex",
    height: "100vh",
    color: "#fff",
    padding: 40,
    gap: 40,
    background: "#0b0618"
  },

  left: { flex: 1 },

  right: {
    width: 400,
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },

  title: { fontSize: 48, fontWeight: 900 },

  desc: { marginTop: 20, opacity: 0.8 },

  btnRow: { display: "flex", gap: 10, marginTop: 20 },

  mainBtn: {
    padding: "14px 24px",
    background: "#7c5cff",
    border: "none",
    color: "#fff"
  },

  subBtn: {
    padding: "14px 24px",
    background: "#222",
    color: "#fff"
  },

  chat: {
    marginTop: 30,
    background: "rgba(255,255,255,0.05)",
    padding: 20,
    borderRadius: 20
  },

  chatInner: {
    height: 200,
    overflowY: "auto",
    display: "flex",
    flexDirection: "column",
    gap: 10
  },

  msg: {
    padding: 10,
    borderRadius: 10,
    maxWidth: "80%"
  },

  inputRow: {
    display: "flex",
    gap: 10,
    marginTop: 10
  },

  input: { flex: 1, padding: 10 },

  sendBtn: { padding: 10 },

  card: {
    background: "rgba(255,255,255,0.05)",
    padding: 40,
    borderRadius: 20
  },

  overlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.5)"
  },

  drawer: {
    position: "fixed",
    bottom: 0,
    left: 0,
    right: 0,
    background: "#111",
    padding: 20,
    transition: "0.3s"
  },

  drawerTitle: {
    fontSize: 24,
    marginBottom: 20
  },

  planRow: {
    display: "flex",
    gap: 10
  },

  plan: {
    flex: 1,
    padding: 20,
    cursor: "pointer"
  },

  buyBtn: {
    marginTop: 10,
    padding: 10,
    background: "#7c5cff",
    color: "#fff"
  }
};