import React, { useEffect, useMemo, useState } from "react";

const STRIPE_LINKS = {
  starter: "https://buy.stripe.com/dRm4gs7E73W7fJ8eQz0kE0f",
  growth: "https://buy.stripe.com/3cI14ge2v8cn54uaAj0kE0g",
  elite: "https://buy.stripe.com/4gM9AMf6zdwHbsSbEn0kE0h"
};

export default function Landing({ onLogin, onOpenPricing }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState("growth");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("pricing") === "open") {
      setDrawerOpen(true);
    }
  }, []);

  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.key === "Escape") {
        setDrawerOpen(false);
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  useEffect(() => {
    if (drawerOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }

    return () => {
      document.body.style.overflow = "";
    };
  }, [drawerOpen]);

  function openDrawer() {
    setDrawerOpen(true);

    if (typeof onOpenPricing === "function") {
      onOpenPricing();
    }
  }

  function closeDrawer() {
    setDrawerOpen(false);
  }

  function goLogin() {
    if (typeof onLogin === "function") {
      onLogin();
      return;
    }

    window.location.href = "/login";
  }

  function goBuy(planKey) {
    const link = STRIPE_LINKS[planKey];
    if (!link) return;
    window.location.href = link;
  }

  function openAIConsultation() {
    setDrawerOpen(true);
    setSelectedPlan("growth");
  }

  const planMeta = useMemo(
    () => ({
      starter: {
        name: "Starter",
        price: "$1280",
        cycle: "/ month",
        note: "月訂閱",
        desc: "適合想先開始、先把 AI 自動成交跑起來的個人品牌或小型商家。",
        features: [
          "AI 自動回覆",
          "自動推付款",
          "客戶分析",
          "基礎追單"
        ]
      },
      growth: {
        name: "Growth",
        price: "$3000",
        cycle: "/ 3 months",
        note: "季訂閱",
        desc: "主推方案。適合想穩定成交、穩定放大的商業使用者。",
        features: [
          "AI 自動回覆",
          "自動推付款",
          "高成交追單",
          "多語言銷售"
        ]
      },
      elite: {
        name: "Elite",
        price: "$10000",
        cycle: "/ year",
        note: "年訂閱",
        desc: "企業級方案。適合高價值品牌、多團隊、多渠道經營。",
        features: [
          "完整 AI 成交流程",
          "高價值客戶策略",
          "全年使用",
          "品牌級運營"
        ]
      }
    }),
    []
  );

  return (
    <div style={styles.page}>
      <div style={styles.bgImage} />
      <div style={styles.bgMask} />
      <div style={styles.bgGlowA} />
      <div style={styles.bgGlowB} />
      <div style={styles.stars} />

      <div style={styles.main}>
        <div style={styles.nav}>
          <div style={styles.logoWrap}>
            <div style={styles.logoOrb} />
            <div>
              <div style={styles.logoTitle}>AI Sales OS</div>
              <div style={styles.logoSub}>Auto Closing System</div>
            </div>
          </div>

          <div style={styles.navBtns}>
            <button style={styles.navGhostBtn} onClick={goLogin}>
              Login
            </button>
          </div>
        </div>

        <div style={styles.hero}>
          <div style={styles.heroLeft}>
            <div style={styles.badge}>AI AUTO-CLOSER</div>

            <h1 style={styles.title}>
              Turn Conversations
              <br />
              Into Revenue
            </h1>

            <p style={styles.subtitle}>
              AI 自動成交系統，幫你自動回覆、自動分析、自動推付款、自動追單。
              不只是工具，而是一套會幫你賺錢的 AI SaaS。
            </p>

            <div style={styles.ctaRow}>
              <button style={styles.primaryBtn} onClick={openDrawer}>
                Get Started
              </button>

              <button style={styles.secondaryBtn} onClick={openAIConsultation}>
                Ask AI
              </button>

              <button style={styles.secondaryBtn} onClick={goLogin}>
                Login
              </button>
            </div>

            <div style={styles.smallInfoRow}>
              <InfoPill text="AI 自動成交" />
              <InfoPill text="Stripe 訂閱" />
              <InfoPill text="多語言回覆" />
            </div>
          </div>

          <div style={styles.heroRight}>
            <div style={styles.robotCard}>
              <div style={styles.robotGlow} />
              <div style={styles.robotStats}>
                <div style={styles.statBox}>
                  <div style={styles.statLabel}>Conversion</div>
                  <div style={styles.statValue}>42%</div>
                </div>
                <div style={styles.statBox}>
                  <div style={styles.statLabel}>Auto Follow-Up</div>
                  <div style={styles.statValue}>ON</div>
                </div>
              </div>

              <div style={styles.robotInner}>
                <div style={styles.robotCircle} />
                <div style={styles.robotTextWrap}>
                  <div style={styles.robotTitle}>AI Revenue Engine</div>
                  <div style={styles.robotText}>
                    自動回覆 / 自動成交 / 自動收款 / 自動追單
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        style={{
          ...styles.overlay,
          ...(drawerOpen ? styles.overlayOpen : {})
        }}
        onClick={closeDrawer}
      />

      <div
        style={{
          ...styles.drawer,
          ...(drawerOpen ? styles.drawerOpen : {})
        }}
      >
        <div style={styles.drawerHandle} />
        <div style={styles.drawerHeader}>
          <div>
            <div style={styles.drawerTitle}>Choose Your Plan</div>
            <div style={styles.drawerSub}>
              選擇最適合你的 AI SaaS 訂閱方案
            </div>
          </div>

          <button style={styles.closeBtn} onClick={closeDrawer}>
            ✕
          </button>
        </div>

        <div style={styles.planGrid}>
          <PlanCard
            active={selectedPlan === "starter"}
            recommended={false}
            name={planMeta.starter.name}
            price={planMeta.starter.price}
            cycle={planMeta.starter.cycle}
            note={planMeta.starter.note}
            desc={planMeta.starter.desc}
            features={planMeta.starter.features}
            onSelect={() => setSelectedPlan("starter")}
            onStart={() => goBuy("starter")}
          />

          <PlanCard
            active={selectedPlan === "growth"}
            recommended
            name={planMeta.growth.name}
            price={planMeta.growth.price}
            cycle={planMeta.growth.cycle}
            note={planMeta.growth.note}
            desc={planMeta.growth.desc}
            features={planMeta.growth.features}
            onSelect={() => setSelectedPlan("growth")}
            onStart={() => goBuy("growth")}
          />

          <PlanCard
            active={selectedPlan === "elite"}
            recommended={false}
            name={planMeta.elite.name}
            price={planMeta.elite.price}
            cycle={planMeta.elite.cycle}
            note={planMeta.elite.note}
            desc={planMeta.elite.desc}
            features={planMeta.elite.features}
            onSelect={() => setSelectedPlan("elite")}
            onStart={() => goBuy("elite")}
          />
        </div>

        <div style={styles.drawerBottomNote}>
          付款完成後，你可以再建立帳號並開始使用你的 AI 自動成交系統。
        </div>
      </div>
    </div>
  );
}

function InfoPill({ text }) {
  return <div style={styles.infoPill}>{text}</div>;
}

function PlanCard({
  active,
  recommended,
  name,
  price,
  cycle,
  note,
  desc,
  features,
  onSelect,
  onStart
}) {
  return (
    <div
      onClick={onSelect}
      style={{
        ...styles.planCard,
        ...(active ? styles.planCardActive : {}),
        ...(recommended ? styles.planCardRecommended : {})
      }}
    >
      {recommended && <div style={styles.recommendBadge}>Most Popular</div>}

      <div style={styles.planTop}>
        <div style={styles.planName}>{name}</div>
        <div style={styles.planNote}>{note}</div>
      </div>

      <div style={styles.priceRow}>
        <span style={styles.planPrice}>{price}</span>
        <span style={styles.planCycle}>{cycle}</span>
      </div>

      <div style={styles.planDesc}>{desc}</div>

      <div style={styles.featureList}>
        {features.map((item) => (
          <div key={item} style={styles.featureItem}>
            ✓ {item}
          </div>
        ))}
      </div>

      <button
        style={{
          ...styles.startBtn,
          ...(active ? styles.startBtnActive : {})
        }}
        onClick={(e) => {
          e.stopPropagation();
          onStart();
        }}
      >
        Continue to Checkout
      </button>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    position: "relative",
    overflow: "hidden",
    color: "#fff",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    background:
      "radial-gradient(circle at top, rgba(31,16,62,1) 0%, rgba(10,7,22,1) 52%, rgba(5,3,12,1) 100%)"
  },

  bgImage: {
    position: "fixed",
    inset: 0,
    backgroundImage:
      "radial-gradient(circle at 25% 20%, rgba(163,112,255,0.18), transparent 24%), radial-gradient(circle at 75% 30%, rgba(103,180,255,0.16), transparent 22%), radial-gradient(circle at 55% 75%, rgba(212,120,255,0.10), transparent 20%)",
    zIndex: 0,
    filter: "blur(6px)"
  },

  bgMask: {
    position: "fixed",
    inset: 0,
    background:
      "linear-gradient(180deg, rgba(7,5,16,0.35), rgba(7,5,16,0.62) 45%, rgba(7,5,16,0.82))",
    zIndex: 1
  },

  bgGlowA: {
    position: "fixed",
    top: -120,
    right: -80,
    width: 420,
    height: 420,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(155,92,255,0.24), transparent 70%)",
    filter: "blur(18px)",
    zIndex: 1
  },

  bgGlowB: {
    position: "fixed",
    bottom: -140,
    left: -120,
    width: 420,
    height: 420,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(91,126,255,0.20), transparent 72%)",
    filter: "blur(18px)",
    zIndex: 1
  },

  stars: {
    position: "fixed",
    inset: 0,
    backgroundImage:
      "radial-gradient(circle, rgba(255,255,255,0.10) 1px, transparent 1.2px)",
    backgroundSize: "42px 42px",
    opacity: 0.1,
    zIndex: 1,
    pointerEvents: "none"
  },

  main: {
    position: "relative",
    zIndex: 2,
    width: "min(1240px, calc(100% - 32px))",
    margin: "0 auto",
    padding: "20px 0 80px"
  },

  nav: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 16,
    padding: "6px 4px 18px"
  },

  logoWrap: {
    display: "flex",
    alignItems: "center",
    gap: 14
  },

  logoOrb: {
    width: 46,
    height: 46,
    borderRadius: 16,
    background:
      "linear-gradient(135deg, rgba(157,92,255,1), rgba(95,124,255,1))",
    boxShadow: "0 0 26px rgba(140,90,255,0.58)"
  },

  logoTitle: {
    fontSize: 20,
    fontWeight: 800,
    letterSpacing: "0.02em"
  },

  logoSub: {
    marginTop: 4,
    fontSize: 12,
    color: "rgba(235,225,255,0.66)"
  },

  navBtns: {
    display: "flex",
    gap: 12
  },

  navGhostBtn: {
    padding: "12px 18px",
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(255,255,255,0.04)",
    color: "#fff",
    cursor: "pointer",
    backdropFilter: "blur(12px)",
    WebkitBackdropFilter: "blur(12px)"
  },

  hero: {
    minHeight: "calc(100vh - 120px)",
    display: "grid",
    gridTemplateColumns: "1.05fr 0.95fr",
    alignItems: "center",
    gap: 28
  },

  heroLeft: {
    maxWidth: 660
  },

  badge: {
    display: "inline-flex",
    alignItems: "center",
    padding: "8px 12px",
    borderRadius: 999,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.10)",
    boxShadow: "0 0 20px rgba(140,90,255,0.14)",
    fontSize: 12,
    letterSpacing: "0.08em",
    color: "#EDE4FF"
  },

  title: {
    marginTop: 18,
    marginBottom: 14,
    fontSize: "clamp(40px, 7vw, 78px)",
    lineHeight: 0.98,
    letterSpacing: "-0.03em"
  },

  subtitle: {
    margin: 0,
    maxWidth: 620,
    fontSize: 17,
    lineHeight: 1.85,
    color: "rgba(235,225,255,0.78)"
  },

  ctaRow: {
    display: "flex",
    gap: 14,
    flexWrap: "wrap",
    marginTop: 28
  },

  primaryBtn: {
    padding: "16px 26px",
    borderRadius: 18,
    border: "1px solid rgba(198,160,255,0.34)",
    background:
      "linear-gradient(135deg, rgba(157,92,255,0.95), rgba(95,124,255,0.95))",
    color: "#fff",
    fontSize: 16,
    fontWeight: 700,
    cursor: "pointer",
    boxShadow: "0 0 34px rgba(140,90,255,0.48)"
  },

  secondaryBtn: {
    padding: "16px 26px",
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.05)",
    color: "#fff",
    fontSize: 16,
    fontWeight: 700,
    cursor: "pointer",
    backdropFilter: "blur(12px)",
    WebkitBackdropFilter: "blur(12px)"
  },

  smallInfoRow: {
    display: "flex",
    gap: 10,
    flexWrap: "wrap",
    marginTop: 24
  },

  infoPill: {
    padding: "10px 12px",
    borderRadius: 999,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#EDE4FF",
    fontSize: 13
  },

  heroRight: {
    display: "flex",
    justifyContent: "center"
  },

  robotCard: {
    position: "relative",
    width: "100%",
    maxWidth: 520,
    minHeight: 500,
    borderRadius: 30,
    overflow: "hidden",
    background:
      "linear-gradient(180deg, rgba(38,24,72,0.62), rgba(17,12,38,0.80))",
    border: "1px solid rgba(255,255,255,0.10)",
    boxShadow:
      "0 30px 90px rgba(0,0,0,0.32), 0 0 60px rgba(140,90,255,0.18), inset 0 0 28px rgba(255,255,255,0.04)"
  },

  robotGlow: {
    position: "absolute",
    top: -80,
    right: -40,
    width: 260,
    height: 260,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(157,92,255,0.30), transparent 70%)",
    filter: "blur(14px)"
  },

  robotStats: {
    display: "flex",
    gap: 12,
    padding: 22,
    position: "relative",
    zIndex: 1
  },

  statBox: {
    flex: 1,
    padding: 14,
    borderRadius: 18,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.09)"
  },

  statLabel: {
    fontSize: 12,
    color: "rgba(235,225,255,0.64)"
  },

  statValue: {
    marginTop: 8,
    fontSize: 24,
    fontWeight: 800
  },

  robotInner: {
    position: "relative",
    zIndex: 1,
    padding: "14px 22px 28px"
  },

  robotCircle: {
    width: "100%",
    height: 300,
    borderRadius: 26,
    background:
      "radial-gradient(circle at center, rgba(132,94,255,0.36), rgba(47,28,94,0.38), rgba(255,255,255,0.02))",
    border: "1px solid rgba(255,255,255,0.08)",
    boxShadow: "inset 0 0 30px rgba(255,255,255,0.03)"
  },

  robotTextWrap: {
    marginTop: 18
  },

  robotTitle: {
    fontSize: 28,
    fontWeight: 800
  },

  robotText: {
    marginTop: 10,
    color: "rgba(235,225,255,0.74)",
    lineHeight: 1.8
  },

  overlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(3,2,10,0.34)",
    backdropFilter: "blur(4px)",
    WebkitBackdropFilter: "blur(4px)",
    opacity: 0,
    pointerEvents: "none",
    transition: "opacity 0.28s ease",
    zIndex: 8
  },

  overlayOpen: {
    opacity: 1,
    pointerEvents: "auto"
  },

  drawer: {
    position: "fixed",
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 9,
    padding: "18px 18px 24px",
    background:
      "linear-gradient(180deg, rgba(28,18,56,0.88), rgba(14,10,30,0.96))",
    borderTop: "1px solid rgba(255,255,255,0.10)",
    boxShadow: "0 -24px 80px rgba(0,0,0,0.34), 0 0 48px rgba(140,90,255,0.16)",
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    backdropFilter: "blur(20px)",
    WebkitBackdropFilter: "blur(20px)",
    transform: "translateY(110%)",
    transition: "transform 0.34s cubic-bezier(.2,.8,.2,1)"
  },

  drawerOpen: {
    transform: "translateY(0)"
  },

  drawerHandle: {
    width: 74,
    height: 6,
    borderRadius: 999,
    background: "rgba(255,255,255,0.18)",
    margin: "0 auto 16px"
  },

  drawerHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 12,
    marginBottom: 18
  },

  drawerTitle: {
    fontSize: 28,
    fontWeight: 800
  },

  drawerSub: {
    marginTop: 8,
    color: "rgba(235,225,255,0.68)"
  },

  closeBtn: {
    width: 42,
    height: 42,
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.05)",
    color: "#fff",
    cursor: "pointer",
    fontSize: 16
  },

  planGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
    gap: 16
  },

  planCard: {
    position: "relative",
    borderRadius: 24,
    padding: 20,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)",
    cursor: "pointer",
    transition: "all 0.24s ease",
    minHeight: 320
  },

  planCardActive: {
    border: "1px solid rgba(196,154,255,0.44)",
    boxShadow: "0 0 34px rgba(140,90,255,0.24)"
  },

  planCardRecommended: {
    background:
      "linear-gradient(180deg, rgba(84,48,160,0.22), rgba(255,255,255,0.05))"
  },

  recommendBadge: {
    position: "absolute",
    top: 16,
    right: 16,
    padding: "7px 10px",
    borderRadius: 999,
    fontSize: 11,
    fontWeight: 700,
    color: "#fff",
    background:
      "linear-gradient(135deg, rgba(157,92,255,0.95), rgba(95,124,255,0.95))",
    boxShadow: "0 0 20px rgba(140,90,255,0.34)"
  },

  planTop: {
    marginBottom: 16
  },

  planName: {
    fontSize: 22,
    fontWeight: 800
  },

  planNote: {
    marginTop: 6,
    color: "rgba(235,225,255,0.66)"
  },

  priceRow: {
    display: "flex",
    alignItems: "flex-end",
    gap: 8,
    marginBottom: 14
  },

  planPrice: {
    fontSize: 40,
    fontWeight: 900,
    letterSpacing: "-0.03em"
  },

  planCycle: {
    paddingBottom: 7,
    color: "rgba(235,225,255,0.64)"
  },

  planDesc: {
    color: "rgba(235,225,255,0.74)",
    lineHeight: 1.8,
    minHeight: 74
  },

  featureList: {
    marginTop: 14,
    marginBottom: 20,
    display: "grid",
    gap: 10
  },

  featureItem: {
    color: "#EDE4FF",
    fontSize: 14
  },

  startBtn: {
    width: "100%",
    padding: "15px 16px",
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.06)",
    color: "#fff",
    fontWeight: 800,
    cursor: "pointer"
  },

  startBtnActive: {
    background:
      "linear-gradient(135deg, rgba(157,92,255,0.95), rgba(95,124,255,0.95))",
    boxShadow: "0 0 30px rgba(140,90,255,0.34)"
  },

  drawerBottomNote: {
    marginTop: 16,
    color: "rgba(235,225,255,0.64)",
    fontSize: 13
  }
};

