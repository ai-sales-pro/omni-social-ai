import React, { useState } from "react";

export default function Login({ onLoggedIn }) {
  const [email, setEmail] = useState(localStorage.getItem("userEmail") || "");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorText, setErrorText] = useState("");

  async function handleLogin() {
    if (!email.trim()) {
      setErrorText("請輸入 Email");
      return;
    }

    if (!password.trim()) {
      setErrorText("請輸入密碼");
      return;
    }

    try {
      setLoading(true);
      setErrorText("");

      const res = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email,
          password
        })
      });

      const data = await res.json();

      if (!data.ok) {
        setErrorText(data.message || "登入失敗");
        return;
      }

      localStorage.setItem("paid", "true");
      localStorage.setItem("ownerId", data.ownerId || "");
      localStorage.setItem("userEmail", email);
      localStorage.setItem("plan", data.plan || "");

      if (typeof onLoggedIn === "function") {
        onLoggedIn(data);
        return;
      }

      const params = new URLSearchParams(window.location.search);
      params.set("mode", "app");
      params.set("page", "Dashboard");
      window.location.href = `/?${params.toString()}`;
    } catch {
      setErrorText("系統忙碌中，請稍後再試");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={styles.page}>
      <div style={styles.bgGlowA} />
      <div style={styles.bgGlowB} />

      <div style={styles.card}>
        <div style={styles.badge}>LOGIN</div>

        <h1 style={styles.title}>登入你的系統</h1>

        <p style={styles.subtitle}>
          登入後就能直接進入你的 AI 自動成交後台。
        </p>

        {errorText ? <div style={styles.errorBox}>{errorText}</div> : null}

        <div style={styles.form}>
          <input
            style={styles.input}
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />

          <input
            style={styles.input}
            placeholder="密碼"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
            onKeyDown={(e) => {
              if (e.key === "Enter") handleLogin();
            }}
          />

          <button
            style={{
              ...styles.primaryBtn,
              ...(loading ? styles.primaryBtnDisabled : {})
            }}
            onClick={handleLogin}
            disabled={loading}
          >
            {loading ? "登入中..." : "登入並進入系統"}
          </button>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    position: "relative",
    overflow: "hidden",
    background:
      "radial-gradient(circle at top, rgba(31,16,62,1) 0%, rgba(10,7,22,1) 52%, rgba(5,3,12,1) 100%)",
    color: "#fff",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  },

  bgGlowA: {
    position: "absolute",
    top: -120,
    right: -80,
    width: 340,
    height: 340,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(157,92,255,0.22), transparent 70%)",
    filter: "blur(18px)",
    pointerEvents: "none"
  },

  bgGlowB: {
    position: "absolute",
    bottom: -120,
    left: -80,
    width: 320,
    height: 320,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(95,124,255,0.18), transparent 72%)",
    filter: "blur(18px)",
    pointerEvents: "none"
  },

  card: {
    width: "100%",
    maxWidth: 520,
    padding: 30,
    borderRadius: 28,
    position: "relative",
    zIndex: 2,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.10)",
    boxShadow:
      "0 24px 80px rgba(0,0,0,0.34), 0 0 40px rgba(140,90,255,0.16)"
  },

  badge: {
    display: "inline-flex",
    padding: "8px 12px",
    borderRadius: 999,
    background: "rgba(157,92,255,0.14)",
    border: "1px solid rgba(157,92,255,0.24)",
    fontSize: 12,
    fontWeight: 700,
    letterSpacing: "0.08em",
    marginBottom: 16
  },

  title: {
    margin: 0,
    fontSize: 36,
    fontWeight: 900,
    letterSpacing: "-0.03em"
  },

  subtitle: {
    marginTop: 12,
    lineHeight: 1.8,
    color: "rgba(235,225,255,0.78)"
  },

  form: {
    marginTop: 22,
    display: "grid",
    gap: 12
  },

  input: {
    width: "100%",
    padding: "14px 16px",
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.05)",
    color: "#fff",
    outline: "none",
    boxSizing: "border-box"
  },

  primaryBtn: {
    marginTop: 6,
    padding: "14px 18px",
    borderRadius: 14,
    border: "1px solid rgba(198,160,255,0.34)",
    background:
      "linear-gradient(135deg, rgba(157,92,255,0.95), rgba(95,124,255,0.95))",
    color: "#fff",
    fontWeight: 800,
    cursor: "pointer"
  },

  primaryBtnDisabled: {
    opacity: 0.6,
    cursor: "not-allowed"
  },

  errorBox: {
    marginTop: 18,
    padding: 14,
    borderRadius: 16,
    background: "rgba(255,80,80,0.10)",
    border: "1px solid rgba(255,80,80,0.18)",
    color: "#ffd3d3"
  }
};