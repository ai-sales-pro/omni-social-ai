import React, { useEffect, useState } from "react";

function getOwnerId() {
  const params = new URLSearchParams(window.location.search);
  return params.get("ownerId") || "";
}

export default function Payments() {
  const [orders, setOrders] = useState([]);
  const [revenue, setRevenue] = useState({ total: 0, monthly: 0 });
  const [loading, setLoading] = useState(true);

  const ownerId = getOwnerId();

  useEffect(() => {
    async function loadData() {
      if (!ownerId) {
        setLoading(false);
        return;
      }

      try {
        const [ordersRes, revenueRes] = await Promise.all([
          fetch(`/api/orders/${ownerId}`),
          fetch(`/api/revenue/${ownerId}`)
        ]);

        const ordersData = await ordersRes.json();
        const revenueData = await revenueRes.json();

        if (ordersData.ok) setOrders(ordersData.orders || []);
        if (revenueData.ok) {
          setRevenue({
            total: revenueData.total || 0,
            monthly: revenueData.monthly || 0
          });
        }
      } catch (err) {
        console.error("load payments data error:", err);
      } finally {
        setLoading(false);
      }
    }

    loadData();
  }, [ownerId]);

  const paidCount = orders.filter((o) => o.status === "paid").length;
  const pendingCount = orders.filter((o) => o.status === "pending").length;

  return (
    <div>
      <h1 className="page-title">收款系統</h1>
      <p className="page-subtitle">
        {ownerId ? `目前帳號：${ownerId}` : "請帶入 ownerId 才能讀取真資料"}
      </p>

      <div style={{ marginBottom: 20 }}>
        <button className="btn-pro" onClick={() => window.location.reload()}>
          🔄 重新整理資料
        </button>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
          gap: 18,
          marginBottom: 24
        }}
      >
        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <div className="metric-label">總營業額</div>
          <div className="metric-value" style={{ fontSize: 34 }}>
            {loading ? "..." : `$${Number(revenue.total || 0).toLocaleString()}`}
          </div>
          <div className="metric-trend">全部已付款訂單</div>
        </div>

        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <div className="metric-label">本月營業額</div>
          <div className="metric-value" style={{ fontSize: 34 }}>
            {loading ? "..." : `$${Number(revenue.monthly || 0).toLocaleString()}`}
          </div>
          <div className="metric-trend">本月累積</div>
        </div>

        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <div className="metric-label">成功付款</div>
          <div className="metric-value" style={{ fontSize: 34 }}>
            {loading ? "..." : paidCount}
          </div>
          <div className="metric-trend">已付款訂單</div>
        </div>

        <div className="glass-card glow-border" style={{ padding: 20 }}>
          <div className="metric-label">等待付款</div>
          <div className="metric-value" style={{ fontSize: 34 }}>
            {loading ? "..." : pendingCount}
          </div>
          <div className="metric-trend">待付款訂單</div>
        </div>
      </div>

      <div className="glass-card glow-border" style={{ padding: 22 }}>
        <h3 style={{ marginTop: 0, marginBottom: 16 }}>最近收款紀錄</h3>

        <table className="panel-table">
          <thead>
            <tr>
              <th>客戶</th>
              <th>方案</th>
              <th>金額</th>
              <th>狀態</th>
              <th>來源</th>
              <th>建立時間</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((item) => (
              <tr key={item.id}>
                <td>{item.customer_name || "客戶"}</td>
                <td>{item.plan || "-"}</td>
                <td>${Number(item.amount || 0).toLocaleString()}</td>
                <td>
                  <span
                    className="status-pill"
                    style={
                      item.status === "paid"
                        ? {
                            background: "rgba(38, 211, 138, 0.16)",
                            border: "1px solid rgba(38, 211, 138, 0.28)",
                            color: "#7CFFBF"
                          }
                        : {
                            background: "rgba(255, 204, 102, 0.14)",
                            border: "1px solid rgba(255, 204, 102, 0.22)",
                            color: "#FFD978"
                          }
                    }
                  >
                    {item.status === "paid" ? "付款成功" : "等待付款"}
                  </span>
                </td>
                <td>{item.source || "-"}</td>
                <td>
                  {item.created_at
                    ? new Date(item.created_at).toLocaleString()
                    : "-"}
                </td>
              </tr>
            ))}

            {!loading && orders.length === 0 && (
              <tr>
                <td colSpan="6">目前沒有收款資料</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}