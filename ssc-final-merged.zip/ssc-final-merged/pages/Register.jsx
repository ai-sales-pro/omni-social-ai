import React, { useEffect, useState } from "react";

export default function Register({ onRegistered }) {
  const [sessionId, setSessionId] = useState("");
  const [sessionLoading, setSessionLoading] = useState(true);
  const [sessionError, setSessionError] = useState("");

  const [plan, setPlan] = useState("");
  const [amount, setAmount] = useState(0);
  const [customerEmail, setCustomerEmail] = useState("");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [submitting, setSubmitting] = useState(false);
  const [successText, setSuccessText] = useState("");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sid = params.get("session_id") || "";
    setSessionId(sid);

    if (!sid) {
      setSessionError("找不到付款資訊，請重新從訂閱頁進入。");
      setSessionLoading(false);
      return;
    }

    loadStripeSession(sid);
  }, []);

  async function loadStripeSession(sid) {
    try {
      setSessionLoading(true);
      setSessionError("");

      const res = await fetch(
        `/api/stripe/session-info?session_id=${encodeURIComponent(sid)}`
      );

      const data = await res.json();

      if (!data.ok) {
        setSessionError(data.message || "付款資訊驗證失敗");
        setSessionLoading(false);
        return;
      }

      setPlan(data.plan || "");
      setAmount(Number(data.amount || 0));
      setCustomerEmail(data.email || "");
      setEmail(data.email || "");
    } catch {
      setSessionError("目前無法讀取付款資訊，請稍後再試。");
    } finally {
      setSessionLoading(false);
    }
  }

  function getPlanLabel(p) {
    if (p === "starter" || p === "month") return "Starter（月訂閱）";
    if (p === "growth" || p === "quarter") return "Growth（季訂閱）";
    if (p === "elite" || p === "year") return "Elite（年訂閱）";
    return p || "已付款方案";
  }

  function getPlanDesc(p) {
    if (p === "starter" || p === "month") {
      return "適合剛開始導入 AI 自動成交的個人品牌與小型商家。";
    }
    if (p === "growth" || p === "quarter") {
      return "主推方案，適合想穩定成交、穩定放大的商家。";
    }
    if (p === "elite" || p === "year") {
      return "企業級方案，適合高價值品牌、多團隊與長期經營。";
    }
    return "你的付款已驗證成功，現在只差一步就能進入系統。";
  }

  async function handleRegister() {
    if (!sessionId) {
      setSessionError("找不到付款 session");
      return;
    }

    if (!email.trim()) {
      setSessionError("請輸入 Email");
      return;
    }

    if (!password.trim()) {
      setSessionError("請輸入密碼");
      return;
    }

    if (password.length < 6) {
      setSessionError("密碼至少 6 碼");
      return;
    }

    if (password !== confirmPassword) {
      setSessionError("兩次密碼不一致");
      return;
    }

    try {
      setSubmitting(true);
      setSessionError("");
      setSuccessText("");

      const res = await fetch("/api/register-from-payment", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          sessionId,
          email,
          password
        })
      });

      const data = await res.json();

      if (!data.ok) {
        setSessionError(data.message || "建立帳號失敗");
        return;
      }

      setSuccessText("帳號建立成功，正在進入系統...");

      localStorage.setItem("paid", "true");
      localStorage.setItem("ownerId", data.ownerId || "");
      localStorage.setItem("userEmail", email);
      localStorage.setItem("plan", plan || "");

      setTimeout(() => {
        if (typeof onRegistered === "function") {
          onRegistered();
          return;
        }

        const params = new URLSearchParams(window.location.search);
        params.set("mode", "app");
        params.set("page", "Dashboard");
        window.location.href = `/?${params.toString()}`;
      }, 1200);
    } catch {
      setSessionError("系統忙碌中，請稍後再試");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div style={styles.page}>
      <div style={styles.bgGlowA} />
      <div style={styles.bgGlowB} />
      <div style={styles.grid} />

      <div style={styles.card}>
        <div style={styles.badge}>PAYMENT VERIFIED</div>

        <h1 style={styles.title}>建立你的帳號</h1>

        <p style={styles.subtitle}>
          付款成功後，這一步只要設定帳號，就能直接進入你的 AI 自動成交系統。
        </p>

        {sessionLoading ? (
          <div style={styles.infoBox}>正在確認付款資訊...</div>
        ) : sessionError ? (
          <div style={styles.errorBox}>{sessionError}</div>
        ) : (
          <div style={styles.planHero}>
            <div style={styles.planHeroTop}>
              <div>
                <div style={styles.planMiniLabel}>已開通方案</div>
                <div style={styles.planTitle}>{getPlanLabel(plan)}</div>
              </div>
              <div style={styles.amountTag}>${amount || 0}</div>
            </div>

            <div style={styles.planDesc}>{getPlanDesc(plan)}</div>

            <div style={styles.infoBoxInner}>
              <div style={styles.infoRow}>
                <span style={styles.infoLabel}>付款 Email</span>
                <span style={styles.infoValue}>{customerEmail || "-"}</span>
              </div>

              <div style={styles.infoRow}>
                <span style={styles.infoLabel}>付款狀態</span>
                <span style={styles.successPill}>已驗證成功</span>
              </div>
            </div>
          </div>
        )}

        <div style={styles.form}>
          <input
            style={styles.input}
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />

          <input
            style={styles.input}
            placeholder="密碼（至少 6 碼）"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
          />

          <input
            style={styles.input}
            placeholder="再次輸入密碼"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            autoComplete="new-password"
          />

          <button
            style={{
              ...styles.primaryBtn,
              ...(submitting || sessionLoading || !!sessionError
                ? styles.primaryBtnDisabled
                : {})
            }}
            onClick={handleRegister}
            disabled={submitting || sessionLoading || !!sessionError}
          >
            {submitting ? "建立中..." : "建立帳號並進入系統"}
          </button>

          {successText ? <div style={styles.successBox}>{successText}</div> : null}
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    position: "relative",
    overflow: "hidden",
    background:
      "radial-gradient(circle at top, rgba(31,16,62,1) 0%, rgba(10,7,22,1) 52%, rgba(5,3,12,1) 100%)",
    color: "#fff",
    fontFamily:
      'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'
  },

  bgGlowA: {
    position: "absolute",
    top: -140,
    right: -80,
    width: 360,
    height: 360,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(157,92,255,0.22), transparent 70%)",
    filter: "blur(18px)",
    pointerEvents: "none"
  },

  bgGlowB: {
    position: "absolute",
    bottom: -120,
    left: -100,
    width: 340,
    height: 340,
    borderRadius: "50%",
    background: "radial-gradient(circle, rgba(95,124,255,0.18), transparent 72%)",
    filter: "blur(18px)",
    pointerEvents: "none"
  },

  grid: {
    position: "absolute",
    inset: 0,
    backgroundImage:
      "radial-gradient(circle, rgba(255,255,255,0.08) 1px, transparent 1.2px)",
    backgroundSize: "42px 42px",
    opacity: 0.08,
    pointerEvents: "none"
  },

  card: {
    width: "100%",
    maxWidth: 600,
    padding: 30,
    borderRadius: 28,
    position: "relative",
    zIndex: 2,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.10)",
    boxShadow:
      "0 24px 80px rgba(0,0,0,0.34), 0 0 40px rgba(140,90,255,0.16)"
  },

  badge: {
    display: "inline-flex",
    padding: "8px 12px",
    borderRadius: 999,
    background: "rgba(157,92,255,0.14)",
    border: "1px solid rgba(157,92,255,0.24)",
    fontSize: 12,
    fontWeight: 700,
    letterSpacing: "0.08em",
    marginBottom: 16
  },

  title: {
    margin: 0,
    fontSize: 36,
    fontWeight: 900,
    letterSpacing: "-0.03em"
  },

  subtitle: {
    marginTop: 12,
    lineHeight: 1.8,
    color: "rgba(235,225,255,0.78)"
  },

  planHero: {
    marginTop: 20,
    padding: 18,
    borderRadius: 22,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)"
  },

  planHeroTop: {
    display: "flex",
    justifyContent: "space-between",
    gap: 12,
    alignItems: "center"
  },

  planMiniLabel: {
    fontSize: 12,
    color: "rgba(235,225,255,0.62)"
  },

  planTitle: {
    marginTop: 6,
    fontSize: 24,
    fontWeight: 800
  },

  amountTag: {
    padding: "10px 14px",
    borderRadius: 14,
    background: "rgba(157,92,255,0.14)",
    border: "1px solid rgba(157,92,255,0.24)",
    fontWeight: 800
  },

  planDesc: {
    marginTop: 12,
    lineHeight: 1.8,
    color: "rgba(235,225,255,0.78)"
  },

  infoBox: {
    marginTop: 18,
    padding: 16,
    borderRadius: 18,
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.08)"
  },

  infoBoxInner: {
    marginTop: 16,
    paddingTop: 14,
    borderTop: "1px solid rgba(255,255,255,0.08)"
  },

  infoRow: {
    display: "flex",
    justifyContent: "space-between",
    gap: 12,
    marginBottom: 10
  },

  infoLabel: {
    color: "rgba(235,225,255,0.62)"
  },

  infoValue: {
    fontWeight: 700
  },

  successPill: {
    padding: "6px 10px",
    borderRadius: 999,
    background: "rgba(80,255,160,0.10)",
    border: "1px solid rgba(80,255,160,0.18)",
    color: "#d8ffe9",
    fontSize: 12,
    fontWeight: 700
  },

  form: {
    marginTop: 22,
    display: "grid",
    gap: 12
  },

  input: {
    width: "100%",
    padding: "14px 16px",
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.05)",
    color: "#fff",
    outline: "none",
    boxSizing: "border-box"
  },

  primaryBtn: {
    marginTop: 6,
    padding: "14px 18px",
    borderRadius: 14,
    border: "1px solid rgba(198,160,255,0.34)",
    background:
      "linear-gradient(135deg, rgba(157,92,255,0.95), rgba(95,124,255,0.95))",
    color: "#fff",
    fontWeight: 800,
    cursor: "pointer"
  },

  primaryBtnDisabled: {
    opacity: 0.6,
    cursor: "not-allowed"
  },

  errorBox: {
    marginTop: 18,
    padding: 14,
    borderRadius: 16,
    background: "rgba(255,80,80,0.10)",
    border: "1px solid rgba(255,80,80,0.18)",
    color: "#ffd3d3"
  },

  successBox: {
    padding: 14,
    borderRadius: 16,
    background: "rgba(80,255,160,0.10)",
    border: "1px solid rgba(80,255,160,0.18)",
    color: "#d8ffe9"
  }
};