import cron from "node-cron";
import axios from "axios";
import { createClient } from "@supabase/supabase-js";

const TELEGRAM_API = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}`;

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// 啟動神級追單系統
export function startFollowUp() {
  cron.schedule("0 * * * *", async () => {
    console.log("🔁 神級追單檢查中...");

    try {
      const { data: customers, error } = await supabase
        .from("customers")
        .select("*");

      if (error) {
        console.log("❌ 讀取 customers 失敗:", error.message);
        return;
      }

      if (!customers || customers.length === 0) {
        console.log("ℹ️ 沒有客戶資料");
        return;
      }

      const now = new Date();

      for (const customer of customers) {
        try {
          if (!customer.chat_id || !customer.updated_at) continue;

          const lastTime = new Date(customer.updated_at);
          const diffHours = (now - lastTime) / (1000 * 60 * 60);

          const followupStage = Number(customer.followup_stage || 0);
          const intent = customer.intent || "其他";
          const level = customer.level || "興趣";
          const emotion = customer.emotion || "好奇";
          const lastMessage = customer.last_message || "";

          // 3小時
          if (diffHours >= 3 && followupStage < 1) {
            const text = buildSuperFollowUpMessage({
              stage: 1,
              intent,
              level,
              emotion,
              lastMessage
            });

            const sent = await sendFollowUp(customer.chat_id, text);
            if (sent) {
              await markFollowUp(customer.chat_id, 1);
            }
            continue;
          }

          // 24小時
          if (diffHours >= 24 && followupStage < 2) {
            const text = buildSuperFollowUpMessage({
              stage: 2,
              intent,
              level,
              emotion,
              lastMessage
            });

            const sent = await sendFollowUp(customer.chat_id, text);
            if (sent) {
              await markFollowUp(customer.chat_id, 2);
            }
            continue;
          }

          // 72小時
          if (diffHours >= 72 && followupStage < 3) {
            const text = buildSuperFollowUpMessage({
              stage: 3,
              intent,
              level,
              emotion,
              lastMessage
            });

            const sent = await sendFollowUp(customer.chat_id, text);
            if (sent) {
              await markFollowUp(customer.chat_id, 3);
            }
            continue;
          }

          // 7天
          if (diffHours >= 168 && followupStage < 4) {
            const text = buildSuperFollowUpMessage({
              stage: 4,
              intent,
              level,
              emotion,
              lastMessage
            });

            const sent = await sendFollowUp(customer.chat_id, text);
            if (sent) {
              await markFollowUp(customer.chat_id, 4);
            }
          }
        } catch (innerErr) {
          console.log("❌ 單一客戶追單失敗:", innerErr.message);
        }
      }
    } catch (err) {
      console.log("❌ 追單系統錯誤:", err.message);
    }
  });
}

// 建立神級追單訊息
function buildSuperFollowUpMessage({ stage, intent, level, emotion, lastMessage }) {
  const role = generateFollowUpRole(intent);
  const context = analyzeMessageContext(lastMessage);

  // Stage 1：輕提醒
  if (stage === 1) {
    if (intent === "感情") {
      if (context.price) {
        return `${role}剛剛有再幫你看一下，你這個狀況不是完全沒機會，只是現在有點卡住，方法要用對。`;
      }
      if (emotion === "難過" || emotion === "焦慮") {
        return `${role}剛剛有再幫你看，你現在這種感情狀況不是沒希望，是節點還沒處理對。`;
      }
      return `我剛剛有再幫你看一下，其實你這段關係還有可以慢慢拉回來的空間。`;
    }

    if (intent === "財運") {
      if (context.price) {
        return `${role}剛剛有再幫你看，你這個不是沒財，是財路有點卡住，所以做法會很重要。`;
      }
      if (emotion === "急迫") {
        return `我剛剛有再幫你看，你現在這個財運問題其實不是單純運氣差，是流動有點堵住。`;
      }
      return `你之前提到的財運方向，我剛剛有再幫你看，其實還有一個可以調整的點。`;
    }

    if (intent === "詢價") {
      if (level === "成交" || context.price) {
        return `${role}剛剛有再整理一下你的狀況，其實你這邊是可以直接幫你配比較適合的方案。`;
      }
      return `我剛剛有再看一下，其實你這個需求不難處理，重點是要用對方式。`;
    }

    return `${role}剛剛有再幫你看一下，其實這個情況還有空間，不一定像你現在想的那麼難。`;
  }

  // Stage 2：建立信任
  if (stage === 2) {
    if (intent === "感情") {
      if (context.breakup || context.noReply) {
        return `你之前那個狀況，我有再幫你分析，像這種冷掉或不回，不一定是沒感情，很多時候是卡在情緒跟節點。`;
      }
      if (context.price) {
        return `你前面問的那個，我有再幫你看，像你這種狀況如果拖太久，後面會更難拉回，現在處理反而比較剛好。`;
      }
      return `你之前那個感情問題，我還記得，如果你現在還在想，我可以再幫你看更適合你的方向。`;
    }

    if (intent === "財運") {
      if (context.moneyBlocked) {
        return `你前面提到那種有進有出留不住，其實很像財路跟財庫都不太穩，這種就不是只靠努力而已。`;
      }
      if (context.price) {
        return `你之前問的財運方向，其實不是不能做，是要用對方法，不然很容易一直卡在同一個地方。`;
      }
      return `你之前提到的財務問題，我有再幫你看，其實還有一個更穩的調整方式。`;
    }

    if (intent === "詢價") {
      if (context.price) {
        return `你前面問的價格和方案我都還記得，如果你要，我可以直接幫你配最適合你的版本。`;
      }
      return `你前面問的需求，我這邊有再整理，如果你要，我可以直接幫你講最適合你的做法。`;
    }

    return `如果你還有在考慮，我可以再幫你看更完整的方向，不用急著現在決定。`;
  }

  // Stage 3：成交推進
  if (stage === 3) {
    if (intent === "感情") {
      return `我直接跟你說，你這個狀況不是沒機會，只是時間點很重要，如果要處理，現在會比再拖更好。`;
    }

    if (intent === "財運") {
      return `你這個財運問題不是努力不夠，是方向有點卡住，所以越早調整，後面越容易順。`;
    }

    if (intent === "詢價") {
      return `你這邊其實已經差不多到可以直接處理的階段了，如果你要，我可以直接幫你定最適合你的方案。`;
    }

    return `你這個狀況其實現在是可以直接往前推的，如果你要，我可以直接幫你看適合你的方式。`;
  }

  // Stage 4：最後提醒
  if (stage === 4) {
    if (intent === "感情") {
      return `我最後再提醒你一次，這段感情不是完全沒機會，只是如果你還想處理，現在會比之後更容易。`;
    }

    if (intent === "財運") {
      return `我最後提醒你一下，你這個不是沒有財，是財路沒完全打開，如果你還想調整，我可以直接幫你看。`;
    }

    if (intent === "詢價") {
      return `我最後跟你確認一次，如果你還想了解，我可以直接幫你定最適合你的方案，這樣你不用自己一直猜。`;
    }

    return `我最後跟你確認一次，如果你還想了解，我可以直接幫你看最適合你的方式。`;
  }

  return `我剛剛有再幫你看一下，如果你還在想，我可以再幫你分析。`;
}

// 10000+ 職業變化追單角色
function generateFollowUpRole(intent) {
  const domains = {
    感情: ["感情", "關係", "復合", "婚姻", "桃花", "曖昧"],
    財運: ["財務", "收入", "偏財", "金流", "商業", "投資"],
    詢價: ["銷售", "成交", "方案", "報價", "商務", "轉換"],
    其他: ["顧問", "策略", "分析", "規劃", "服務", "專家"]
  };

  const levels = [
    "首席", "國際級", "頂級", "王牌", "私人", "高端", "資深", "專業級", "核心", "菁英"
  ];

  const styles = [
    "引導型", "共鳴型", "成交型", "分析型", "策略型",
    "精準型", "高端型", "洞察型", "談判型", "轉換型"
  ];

  const titles = [
    "顧問", "專家", "導師", "規劃師", "分析師",
    "策略師", "經理", "教練", "顧問師", "成交師"
  ];

  const domainList = domains[intent] || domains["其他"];
  const level = randomPick(levels);
  const domain = randomPick(domainList);
  const style = randomPick(styles);
  const title = randomPick(titles);

  return `${level}${domain}${style}${title}`;
}

// 分析客戶上次訊息內容
function analyzeMessageContext(message = "") {
  const text = String(message);

  return {
    price:
      text.includes("價格") ||
      text.includes("多少") ||
      text.includes("費用") ||
      text.includes("方案") ||
      text.includes("怎麼做") ||
      text.includes("報價"),

    breakup:
      text.includes("分手") ||
      text.includes("斷聯") ||
      text.includes("前任"),

    noReply:
      text.includes("不回") ||
      text.includes("已讀") ||
      text.includes("冷淡") ||
      text.includes("沒聯絡"),

    moneyBlocked:
      text.includes("沒錢") ||
      text.includes("留不住") ||
      text.includes("財運") ||
      text.includes("偏財") ||
      text.includes("收入")
  };
}

function randomPick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// 發送追單
async function sendFollowUp(chatId, text) {
  try {
    await axios.post(`${TELEGRAM_API}/sendMessage`, {
      chat_id: chatId,
      text
    });

    console.log("✅ 已發送追單:", chatId);
    return true;
  } catch (e) {
    console.log("❌ 發送追單失敗:", chatId, e.message);
    return false;
  }
}

// 更新追單階段
async function markFollowUp(chatId, stage) {
  const payload = {
    followup_stage: stage,
    followup_sent_at: new Date().toISOString()
  };

  const { error } = await supabase
    .from("customers")
    .update(payload)
    .eq("chat_id", chatId);

  if (error) {
    console.log("❌ 更新 followup_stage 失敗:", error.message);
  } else {
    console.log(`📝 已更新 ${chatId} 的追單階段為 ${stage}`);
  }
}