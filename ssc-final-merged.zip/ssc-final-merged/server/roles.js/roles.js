export function generateJobRole(analysis = {}) {
  const domains = {
    感情: ["感情", "關係", "復合", "婚姻", "曖昧"],
    財運: ["財務", "收入", "偏財", "投資", "商業"],
    詢價: ["銷售", "成交", "方案", "報價"],
    其他: ["顧問", "專家", "策略"]
  };

  const levels = ["頂級", "國際級", "首席", "私人", "王牌"];
  const styles = ["共鳴型", "成交型", "分析型", "引導型", "策略型"];

  const field = random(domains[analysis.intent] || domains["其他"]);
  const level = random(levels);
  const style = random(styles);

  return `${level}${field}${style}專家`;
}

function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}