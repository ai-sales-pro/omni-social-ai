import crypto from "crypto";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

function hashPassword(password = "") {
  return crypto.createHash("sha256").update(String(password)).digest("hex");
}

function makeOwnerId() {
  const random = crypto.randomBytes(4).toString("hex");
  return `boss_${random}`;
}

async function getUserByEmail(email) {
  const { data, error } = await supabase
    .from("users")
    .select("*")
    .eq("email", String(email))
    .maybeSingle();

  if (error) throw error;
  return data;
}

async function createDefaultAISettings(ownerId) {
  const { error } = await supabase
    .from("ai_settings")
    .upsert(
      {
        owner_id: String(ownerId),
        auto_reply: true,
        auto_payment_push: true,
        customer_analysis: true,
        follow_up_mode: "standard",
        default_plan: "growth",
        tone_style: "closing",
        auto_mode: true,
        industry: "fortune",
        primary_language: "zh-TW",
        business_name: "",
        product_name: "",
        product_price: 0,
        brand_style: "",
        custom_prompt: "",
        updated_at: new Date().toISOString()
      },
      { onConflict: "owner_id" }
    );

  if (error) throw error;
}

async function createUserFromPaidSession({ email, password, plan }) {
  const existingUser = await getUserByEmail(email);

  if (existingUser) {
    return {
      ok: true,
      ownerId: existingUser.owner_id,
      plan: existingUser.plan || plan,
      isExisting: true
    };
  }

  let ownerId = makeOwnerId();

  for (let i = 0; i < 5; i++) {
    const { data, error } = await supabase
      .from("users")
      .select("owner_id")
      .eq("owner_id", ownerId)
      .maybeSingle();

    if (error) throw error;
    if (!data) break;
    ownerId = makeOwnerId();
  }

  const passwordHash = hashPassword(password);

  const { error: userError } = await supabase.from("users").insert({
    owner_id: ownerId,
    email,
    password_hash: passwordHash,
    plan,
    status: "active"
  });

  if (userError) throw userError;

  const { error: subError } = await supabase.from("subscriptions").insert({
    owner_id: ownerId,
    plan,
    status: "active",
    started_at: new Date().toISOString()
  });

  if (subError) throw subError;

  const { error: paymentError } = await supabase
    .from("payment_settings")
    .upsert(
      {
        owner_id: ownerId,
        payment_link: "",
        updated_at: new Date().toISOString()
      },
      { onConflict: "owner_id" }
    );

  if (paymentError) throw paymentError;

  await createDefaultAISettings(ownerId);

  return {
    ok: true,
    ownerId,
    plan,
    isExisting: false
  };
}

async function verifyPaidSession(sessionId) {
  const session = await stripe.checkout.sessions.retrieve(sessionId);

  if (!session) {
    return {
      ok: false,
      message: "找不到付款 session"
    };
  }

  if (session.payment_status !== "paid") {
    return {
      ok: false,
      message: "付款尚未完成"
    };
  }

  const email = session.customer_email || "";
  const amount = Number(session.amount_total || 0) / 100;

  let plan = "growth";
  if (amount === 1280) plan = "starter";
  if (amount === 3000) plan = "growth";
  if (amount === 10000) plan = "elite";

  return {
    ok: true,
    session,
    email,
    amount,
    plan
  };
}

export async function getStripeSessionInfo(req, res) {
  try {
    const sessionId = req.query.session_id || req.query.sessionId || "";

    if (!sessionId) {
      return res.json({
        ok: false,
        message: "missing session_id"
      });
    }

    const verified = await verifyPaidSession(sessionId);

    if (!verified.ok) {
      return res.json(verified);
    }

    return res.json({
      ok: true,
      email: verified.email,
      amount: verified.amount,
      plan: verified.plan
    });
  } catch (err) {
    console.log("getStripeSessionInfo error:", err.message);
    return res.status(500).json({
      ok: false,
      message: "stripe session error"
    });
  }
}

export async function registerFromPayment(req, res) {
  try {
    const { sessionId, email, password } = req.body || {};

    if (!sessionId || !email || !password) {
      return res.json({
        ok: false,
        message: "missing fields"
      });
    }

    const verified = await verifyPaidSession(sessionId);

    if (!verified.ok) {
      return res.json(verified);
    }

    if (
      verified.email &&
      String(verified.email).toLowerCase() !== String(email).toLowerCase()
    ) {
      return res.json({
        ok: false,
        message: "付款 Email 與註冊 Email 不一致"
      });
    }

    const created = await createUserFromPaidSession({
      email,
      password,
      plan: verified.plan
    });

    return res.json({
      ok: true,
      ownerId: created.ownerId,
      plan: created.plan,
      isExisting: created.isExisting
    });
  } catch (err) {
    console.log("registerFromPayment error:", err.message);
    return res.status(500).json({
      ok: false,
      message: "register failed"
    });
  }
}

export async function loginWithPassword(req, res) {
  try {
    const { email, password } = req.body || {};

    if (!email || !password) {
      return res.json({
        ok: false,
        message: "missing fields"
      });
    }

    const user = await getUserByEmail(email);

    if (!user) {
      return res.json({
        ok: false,
        message: "帳號不存在"
      });
    }

    const passwordHash = hashPassword(password);

    if (user.password_hash !== passwordHash) {
      return res.json({
        ok: false,
        message: "密碼錯誤"
      });
    }

    return res.json({
      ok: true,
      ownerId: user.owner_id,
      plan: user.plan || "",
      email: user.email || ""
    });
  } catch (err) {
    console.log("loginWithPassword error:", err.message);
    return res.status(500).json({
      ok: false,
      message: "login failed"
    });
  }
}